<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use XeMenu;
use XeSkin;
use Xpressengine\Document\Models\Document;
use Xpressengine\Permission\Instance;
use Xpressengine\Plugins\Board\BoardPermissionHandler;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Comment\Models\Comment;
use Xpressengine\User\Models\User;

/**
 * 사이트·메뉴·게시판·글·댓글·첨부·페이지. 권한은 XE3 엔진(Gate·게시판 권한)이 판단한 결과를 그대로 쓴다.
 * 글·댓글·회원·파일 번호는 Store::num() 으로 정수로 바꿔 준다.
 */
class Boards
{
    const BOARD = 'board@board';
    const PAGE = 'page@page';
    /** 글·댓글 쓰기 API 를 넣기 전까지 앱의 글쓰기 버튼·댓글 입력창을 숨긴다 (앱은 서버가 준 권한이 참일 때만 보인다) */
    const WRITE_READY = false;

    // ---- 공통

    public static function absolute($url)
    {
        $url = (string)$url;
        if ($url === '' || preg_match('#^(https?:)?//#i', $url)) {
            return $url;
        }
        return rtrim(url('/'), '/') . '/' . ltrim($url, '/');
    }

    /** 본문 HTML: XE3 가 씌우는 <div class="__xe_contents_compiler"><xe-content …> 껍데기를 벗긴다 (앱은 순수 HTML 을 그린다) */
    private static function html($instanceId, $content, $isHtml)
    {
        $html = (string)compile($instanceId, $content, $isHtml);
        $html = preg_replace('#^\s*<div class="__xe_contents_compiler">\s*<xe-content[^>]*>#s', '', $html, 1, $count);
        if ($count) {
            $html = preg_replace('#</xe-content>\s*</div>\s*$#s', '', $html, 1);
        }
        return trim($html);
    }

    /** ISO 8601 (사이트 시간대) */
    private static function iso($time)
    {
        return $time ? \Carbon\Carbon::parse($time)->toIso8601String() : null;
    }

    private static function perm($instanceId)
    {
        return new Instance(app(BoardPermissionHandler::class)->name($instanceId));
    }

    /** 이 회원의 게시판 권한 (엔진의 Gate) */
    public static function grant($instanceId)
    {
        static $cache = [];
        if (!isset($cache[$instanceId])) {
            $perm = self::perm($instanceId);
            $config = app('xe.board.config')->get($instanceId);
            $manager = Gate::allows(BoardPermissionHandler::ACTION_MANAGE, $perm);
            $cache[$instanceId] = [
                'list' => Gate::allows(BoardPermissionHandler::ACTION_LIST, $perm),
                'view' => Gate::allows(BoardPermissionHandler::ACTION_READ, $perm),
                'write_document' => self::WRITE_READY && Gate::allows(BoardPermissionHandler::ACTION_CREATE, $perm),
                'write_comment' => self::WRITE_READY && $config && $config->get('comment') === true && self::canComment($instanceId),
                'manager' => $manager,
            ];
        }
        return $cache[$instanceId];
    }

    /** 댓글 쓰기 권한: 댓글 플러그인의 권한(create) */
    private static function canComment($boardInstanceId)
    {
        $handler = app('xe.plugin.comment')->getHandler();
        $commentInstanceId = $handler->getInstanceId($boardInstanceId);
        if (!$commentInstanceId) {
            return false;
        }
        return Gate::allows('create', new Instance($handler->getKeyForPerm($commentInstanceId)));
    }

    /** 주소(url)의 메뉴 항목. 없으면 null */
    private static function itemByUrl($url)
    {
        if (!is_string($url) || !preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $url)) {
            throw new ApiError(400, 'invalid_mid', 'invalid mid');
        }
        return XeMenu::items()->query()->where('url', $url)->first();
    }

    private static function moduleOf($item)
    {
        $type = (string)$item->type;
        if ($type === self::BOARD) {
            return 'board';
        }
        if ($type === self::PAGE || $type === 'widgetpage@widgetpage') {
            return 'page';
        }
        return null;
    }

    /** 메뉴에서 보이고(visible), 게시판이면 목록 권한도 있는지 */
    private static function isVisible($item)
    {
        $menu = XeMenu::menus()->find($item->menu_id);
        if (!$menu || !$item->activated || Gate::denies('visible', [$item, $menu])) {
            return false;
        }
        return $item->type !== self::BOARD || self::grant($item->id)['list'];
    }

    /** 게시판 mid → [메뉴 항목, 게시판 설정]. 볼 수 없으면 없는 게시판처럼 */
    private static function boardOf($mid)
    {
        $item = self::itemByUrl($mid);
        if (!$item || $item->type !== self::BOARD) {
            throw new ApiError(404, 'board_not_found', '없는 게시판입니다.');
        }
        $config = app('xe.board.config')->get($item->id);
        if (!$config) {
            throw new ApiError(404, 'board_not_found', '없는 게시판입니다.');
        }
        return [$item, $config];
    }

    private static function title($item)
    {
        return trim(strip_tags(xe_trans($item->title)));
    }

    // ---- 사이트·메뉴

    public static function site()
    {
        $site = app('xe.site');
        $config = $site->getSiteConfig();
        $home = $site->getHomeInstanceId();
        $homeItem = $home ? XeMenu::items()->find($home) : null;
        return [
            'name' => trim(xe_trans((string)$config->get('site_title'))) ?: Api::$request->getHost(),
            'base_url' => rtrim(url('/'), '/') . '/',
            'theme_color' => null,
            'logo_url' => null,
            'icon_url' => self::absolute('favicon.ico'),
            'home_mid' => $homeItem ? (string)$homeItem->url : null,
            'engine' => 'xe3',
            'engine_version' => defined('__XE_VERSION__') ? __XE_VERSION__ : null,
            'api_version' => Api::VERSION,
            'member' => Api::profile(),
        ];
    }

    public static function menus()
    {
        $menus = [];
        foreach (XeMenu::menus()->query()->where('site_key', 'default')->get() as $menu) {
            $tree = XeMenu::menus()->findWith($menu->id, []);
            $items = [];
            foreach ($tree->getTree()->getTreeNodes() as $node) {
                if ($out = self::menuItem($node, $menu)) {
                    $items[] = $out;
                }
            }
            if ($items) {
                $menus[] = ['id' => (string)$menu->id, 'title' => (string)$menu->title, 'items' => $items];
            }
        }
        return ['menus' => $menus];
    }

    /** 권한 없는 항목은 빼고, 하위에 볼 것이 남은 경우에만 제목만 있는 묶음으로 남긴다 */
    private static function menuItem($item, $menu)
    {
        if (!$item->activated || Gate::denies('visible', [$item, $menu])) {
            return null;
        }
        $children = [];
        foreach ($item->getChildren() as $child) {
            if ($out = self::menuItem($child, $menu)) {
                $children[] = $out;
            }
        }
        $module = self::moduleOf($item);
        $grant = null;
        if ($module === 'board') {
            $g = self::grant($item->id);
            if (!$g['list']) {
                return $children ? ['title' => self::title($item), 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $children] : null;
            }
            $grant = ['view' => $g['view'], 'write_document' => $g['write_document'], 'write_comment' => $g['write_comment']];
        }
        $url = $module ? self::absolute($item->url) : self::absolute((string)$item->url);
        return [
            'title' => self::title($item),
            'mid' => $module ? (string)$item->url : null,
            'module' => $module,
            'grant' => $grant,
            'url' => $url !== '' ? $url : null,
            'open_window' => $item->target === '_blank',
            'children' => $children,
        ];
    }

    /** 메뉴에 있는 게시판 중 목록을 볼 수 있는 곳 (모아 보기 기본 대상) */
    private static function visibleBoards()
    {
        $boards = [];
        foreach (XeMenu::items()->query()->where('type', self::BOARD)->where('activated', 1)->get() as $item) {
            if (self::isVisible($item)) {
                $boards[$item->id] = $item;
            }
        }
        return $boards;
    }

    // ---- 게시판

    private static function listColumns($config)
    {
        $columns = (array)($config->get('listColumns') ?: \Xpressengine\Plugins\Board\ConfigHandler::DEFAULT_SELECTED_LIST_COLUMNS);
        return ['read_count' => in_array('read_count', $columns), 'vote_count' => in_array('assent_count', $columns)];
    }

    private static function style($instanceId)
    {
        $skin = XeSkin::getAssigned(['module/board@board', $instanceId]);
        $id = $skin ? strtolower($skin->getId()) : '';
        foreach (['gallery', 'webzine', 'blog' => 'webzine', 'calendar'] as $key => $style) {
            $needle = is_int($key) ? $style : $key;
            if (strpos($id, $needle) !== false) {
                return $style;
            }
        }
        return 'list';
    }

    public static function boardInfo($item, $config)
    {
        $grant = self::grant($item->id);
        $categories = [];
        if ($config->get('category') === true && $config->get('categoryId')) {
            $walk = function ($items, $parent) use (&$walk, &$categories) {
                foreach ($items as $c) {
                    $categories[] = ['category_srl' => (int)$c->id, 'parent_srl' => (int)$parent, 'title' => trim(xe_trans($c->word)), 'document_count' => 0];
                    $walk($c->getChildren(), $c->id);
                }
            };
            $roots = \Xpressengine\Category\Models\CategoryItem::where('category_id', $config->get('categoryId'))->whereNull('parent_id')->orderBy('ordering')->get();
            $walk($roots, 0);
        }
        return [
            'mid' => (string)$item->url,
            'title' => self::title($item),
            'style' => self::style($item->id),
            'columns' => self::listColumns($config),
            'use_secret' => $config->get('secretPost') === true,
            'categories' => $categories,
            'grant' => $grant,
            // 글쓰기는 다음 단계: 지금은 사진 첨부를 막는다
            'upload' => ['allowed' => false, 'max_file_size' => null, 'max_total_size' => null],
        ];
    }

    /** 앱의 문서요약 */
    private static function summary(Board $doc, $config, $canView)
    {
        $user = Auth::user();
        $secret = (int)$doc->display === Document::DISPLAY_SECRET;
        $mine = Auth::check() && $doc->user_id && $doc->user_id === $user->getId();
        $accessible = $canView && (!$secret || $mine || self::grant($doc->instance_id)['manager']);
        $columns = self::listColumns($config);
        $plain = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string)$doc->pure_content ?: (string)$doc->content), ENT_QUOTES, 'UTF-8')));
        $thumb = $doc->thumb ?? null;
        $anonymous = $doc->user_type === Document::USER_TYPE_ANONYMITY || $doc->user_type === Document::USER_TYPE_GUEST;
        return [
            'document_srl' => Store::num($doc->id),
            'title' => (string)$doc->title,
            'author' => (string)$doc->writer,
            'author_image' => (!$anonymous && $doc->user) ? Api::profileImage($doc->user) : null,
            'author_srl' => (!$anonymous && $doc->user_id) ? Store::num($doc->user_id) : 0,
            'is_mine' => (bool)$mine,
            'regdate' => self::iso($doc->created_at),
            'last_update' => self::iso($doc->updated_at),
            'category_srl' => (int)($doc->boardCategory->item_id ?? 0),
            'comment_count' => (int)$doc->comment_count,
            'read_count' => $columns['read_count'] ? (int)$doc->read_count : null,
            'vote_count' => $columns['vote_count'] ? (int)$doc->assent_count : null,
            'is_notice' => (int)$doc->status === Document::STATUS_NOTICE,
            'is_secret' => $secret,
            'has_files' => (int)($doc->boardData->file_count ?? 0) > 0,
            'thumbnail' => ($accessible && $thumb && $thumb->board_thumbnail_path) ? self::absolute($thumb->board_thumbnail_path) : null,
            'summary' => $accessible ? mb_substr($plain, 0, 120) : '',
        ];
    }

    /** 게시판 목록용 요청 (웹 목록과 같은 조건: 페이지·분류·검색) */
    private static function listRequest()
    {
        $r = Api::$request;
        $q = ['page' => max(1, Api::intParam('page', 1))];
        if ($c = Api::intParam('category')) {
            $q['category_item_id'] = $c;
        }
        $keyword = trim((string)Api::param('search_keyword', ''));
        if ($keyword !== '') {
            $target = (string)Api::param('search_target', 'title_content');
            $map = ['title' => 'title', 'content' => 'content', 'title_content' => 'title_pure_content', 'nick_name' => 'writer', 'user_id' => 'writer'];
            $q[$map[$target] ?? 'title_pure_content'] = $keyword;
        }
        $list = Request::create($r->url(), 'GET', $q);
        $list->setUserResolver(function () { return Auth::user(); });
        \Illuminate\Pagination\Paginator::currentPageResolver(function () use ($q) { return $q['page']; });
        return $list;
    }

    public static function board()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        if (!self::isVisible($item)) {
            // 목록 권한이 없으면 웹처럼 막는다 (비회원이면 로그인을 권하도록 401)
            throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', Api::message('not_permitted'));
        }
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $request = self::listRequest();
        $canView = self::grant($item->id)['view'];
        $notices = [];
        if ($request->get('page', 1) == 1) {
            foreach ($service->getNoticeItems($request, $config, Auth::user()->getId()) as $doc) {
                $notices[] = self::summary($doc, $config, $canView);
            }
        }
        $paginate = $service->getItems($request, $config);
        $documents = [];
        foreach ($paginate as $doc) {
            $documents[] = self::summary($doc, $config, $canView);
        }
        return [
            'board' => self::boardInfo($item, $config),
            'notices' => $notices,
            'documents' => $documents,
            'page' => (int)$paginate->currentPage(),
            'total_pages' => max(1, (int)$paginate->lastPage()),
            'total_count' => (int)$paginate->total(),
        ];
    }

    public static function feed()
    {
        $boards = self::visibleBoards();
        $mids = array_filter(explode(',', (string)Api::param('mids', '')));
        if ($mids) {
            $boards = array_filter($boards, function ($item) use ($mids) { return in_array($item->url, $mids, true); });
        }
        $count = min(50, max(5, Api::intParam('list_count', 20)));
        $page = max(1, Api::intParam('page', 1));
        if (!$boards) {
            return ['documents' => [], 'page' => 1, 'total_pages' => 1];
        }
        $query = Board::whereIn('instance_id', array_keys($boards))
            ->where('status', '!=', Document::STATUS_TRASH)
            ->where('approved', Document::APPROVED_APPROVED)
            ->where('published', Document::PUBLISHED_PUBLISHED)
            ->where('display', '!=', Document::DISPLAY_HIDDEN)
            ->orderBy('head', 'desc');
        $paginate = $query->paginate($count, ['*'], 'page', $page);
        $documents = [];
        foreach ($paginate as $doc) {
            $item = $boards[$doc->instance_id];
            $config = app('xe.board.config')->get($doc->instance_id);
            $summary = self::summary($doc, $config, self::grant($doc->instance_id)['view']);
            $summary['mid'] = (string)$item->url;
            $summary['board_title'] = self::title($item);
            $documents[] = $summary;
        }
        return ['documents' => $documents, 'page' => $page, 'total_pages' => max(1, (int)$paginate->lastPage())];
    }

    /** 글 하나 + 읽기 권한 확인 (웹의 BoardModuleController::show 와 같은 판단) */
    private static function readable($item, $config, $documentSrl)
    {
        $uuid = Store::uuid($documentSrl);
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $user = Auth::user();
        $manager = self::grant($item->id)['manager'];
        try {
            $doc = $uuid ? $service->getItem($uuid, $user, $config, $manager) : null;
        } catch (\Xpressengine\Plugins\Board\Exceptions\NotFoundDocumentException $e) {
            $doc = null;
        } catch (\Xpressengine\Plugins\Board\Exceptions\GuestWrittenSecretDocumentException $e) {
            throw new ApiError(403, 'not_permitted', '비밀글입니다.');
        }
        if (!$doc || $doc->instance_id !== $item->id) {
            throw new ApiError(404, 'document_not_found', '없는 글입니다.');
        }
        $own = $service->hasItemPerm($doc, $user, app('xe.board.identify'), $manager);
        if (!$own && !self::grant($item->id)['view']) {
            throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', Api::message('not_permitted'));
        }
        if ($config->get('useConsultation') === true && !$own) {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        return [$doc, $own];
    }

    public static function document()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        $documentSrl = Api::intParam('document_srl');
        if (!$documentSrl) {
            throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
        }
        list($doc, $own) = self::readable($item, $config, $documentSrl);
        if ((int)$doc->display === Board::DISPLAY_VISIBLE) {
            app('xe.board.handler')->incrementReadCount($doc, Auth::user());
        }
        $grant = self::grant($item->id);
        $data = self::summary($doc, $config, true);
        $data['content_html'] = self::html($doc->instance_id, $doc->content, $doc->format === Board::FORMAT_HTML);
        $data['files'] = self::files($doc, $item);
        $data['extra_vars'] = [];
        $data['permanent_url'] = self::absolute(app('xe.board.url')->getShow($doc));
        $data['can_comment'] = $grant['write_comment'] && (int)($doc->boardData->allow_comment ?? 1) === 1;
        $data['can_edit'] = false; // 고치기·지우기는 다음 단계
        $data['can_delete'] = false;
        $data['board'] = self::boardInfo($item, $config);
        $data['comments'] = self::commentPage($doc);
        return $data;
    }

    public static function comments()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        list($doc) = self::readable($item, $config, Api::intParam('document_srl'));
        return self::commentPage($doc);
    }

    /** 댓글: 웹처럼 head(최신 묶음)·reply(답글 순서) 순서, 20개씩 */
    private static function commentPage(Board $doc)
    {
        $handler = app('xe.plugin.comment')->getHandler();
        $instanceId = $handler->getInstanceId($doc->instance_id);
        $empty = ['items' => [], 'page' => 1, 'total_pages' => 1, 'total_count' => 0];
        if (!$instanceId) {
            return $empty;
        }
        $config = $handler->getConfig($instanceId);
        $direction = $config->get('reverse') === true ? 'asc' : 'desc';
        $query = $handler->createModel($instanceId)->newQuery()
            ->whereHas('target', function ($q) use ($doc) {
                $q->where('target_id', $doc->id)->where('target_type', Board::class);
            })
            ->where('display', '!=', Comment::DISPLAY_HIDDEN)
            ->where('status', '!=', Comment::STATUS_TRASH)
            ->orderBy('head', $direction)->orderBy('reply', 'asc');
        $perPage = 20;
        $page = max(1, Api::intParam('cpage', 1));
        $paginate = $query->paginate($perPage, ['*'], 'cpage', $page);
        $user = Auth::user();
        $manager = Gate::allows('manage', new Instance($handler->getKeyForPerm($instanceId)));
        $items = [];
        foreach ($paginate as $c) {
            $mine = Auth::check() && $c->user_id && $c->user_id === $user->getId();
            $secret = (int)$c->display === Comment::DISPLAY_SECRET;
            $accessible = !$secret || $mine || $manager || (Auth::check() && $doc->user_id === $user->getId());
            $anonymous = $c->user_type === Document::USER_TYPE_ANONYMITY || $c->user_type === Document::USER_TYPE_GUEST;
            $items[] = [
                'comment_srl' => Store::num($c->id),
                'parent_srl' => $c->parent_id && $c->parent_id !== $doc->id ? Store::num($c->parent_id) : 0,
                'depth' => (int)floor(strlen((string)$c->reply) / Document::getReplyCharLen()),
                'author' => (string)$c->writer,
                'author_image' => (!$anonymous && $c->user) ? Api::profileImage($c->user) : null,
                'author_srl' => (!$anonymous && $c->user_id) ? Store::num($c->user_id) : 0,
                'is_mine' => (bool)$mine,
                'regdate' => self::iso($c->created_at),
                'is_secret' => $secret,
                'content_html' => $accessible ? self::html($instanceId, $c->content, $c->format === Comment::FORMAT_HTML) : null,
                'vote_count' => (int)$c->assent_count,
                'can_delete' => false,
                'files' => [],
            ];
        }
        return [
            'items' => $items,
            'page' => (int)$paginate->currentPage(),
            'total_pages' => max(1, (int)$paginate->lastPage()),
            'total_count' => (int)$paginate->total(),
        ];
    }

    private static function files(Board $doc, $item)
    {
        $out = [];
        foreach ($doc->files as $file) {
            $image = strpos((string)$file->mime, 'image/') === 0;
            $out[] = [
                'file_srl' => Store::num($file->id),
                'name' => (string)$file->clientname,
                'size' => (int)$file->size,
                'is_image' => $image,
                'image_url' => $image ? self::absolute($file->url()) : null,
                'download' => ['r' => 'file', 'file_srl' => Store::num($file->id), 'mid' => (string)$item->url, 'document_srl' => Store::num($doc->id)],
            ];
        }
        return $out;
    }

    /** 첨부 내려받기: 글을 읽을 수 있고 에디터의 다운로드 권한이 있을 때 (웹 EditorController::download 와 같은 판단) */
    public static function file()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        list($doc) = self::readable($item, $config, Api::intParam('document_srl'));
        $uuid = Store::uuid(Api::intParam('file_srl'));
        $file = $uuid ? $doc->files->firstWhere('id', $uuid) : null;
        if (!$file) {
            throw new ApiError(404, 'not_found', Api::message('not_found'));
        }
        $editor = app('xe.editor');
        if (Gate::denies('download', new Instance($editor->getPermKey($item->id)))) {
            throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', '파일을 내려받을 권한이 없습니다.');
        }
        return \XeStorage::download($file);
    }

    // ---- 페이지·링크 풀이

    public static function page()
    {
        $item = self::itemByUrl(Api::param('mid'));
        if (!$item || self::moduleOf($item) !== 'page') {
            throw new ApiError(400, 'not_page', 'not a page');
        }
        if (!self::isVisible($item)) {
            throw new ApiError(404, 'not_found', Api::message('not_found'));
        }
        $html = '';
        $type = 'outside';
        if ($item->type === self::PAGE) {
            $handler = app('xe.page.handler');
            $config = $handler->getPageConfig($item->id);
            $uids = (array)$config->get('pcUids');
            $locale = app('xe.translator')->getLocale();
            $uid = $uids[$locale] ?? reset($uids);
            $doc = $uid ? app('xe.document')->get($uid, $item->id) : null;
            $html = $doc ? self::html($item->id, $doc->content, true) : '';
            $type = 'article';
        }
        return [
            'mid' => (string)$item->url,
            'title' => self::title($item),
            'page_type' => $type,
            'content_html' => $html,
            'web_url' => self::absolute($item->url),
        ];
    }

    public static function resolve()
    {
        $mid = (string)Api::param('mid', '');
        $documentSrl = Api::intParam('document_srl');
        $item = $mid !== '' ? self::itemByUrl($mid) : null;
        if (!$item && $documentSrl && ($uuid = Store::uuid($documentSrl))) {
            $doc = Board::find($uuid);
            $item = $doc ? XeMenu::items()->find($doc->instance_id) : null;
        }
        if (!$item || !self::isVisible($item)) {
            throw new ApiError(404, 'not_found', Api::message('not_found'));
        }
        return ['mid' => (string)$item->url, 'module' => self::moduleOf($item), 'title' => self::title($item), 'document_srl' => $documentSrl ?: null];
    }
}
