<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * 플러그인이 쓰는 표 두 개.
 * - appapi_ids: XE3 의 UUID(글·댓글·회원·파일) ↔ 앱이 쓰는 정수 번호. 앱(1.0부터)은 정수 번호만 다룬다.
 * - appapi_tokens: 기기별 로그인 토큰 (원문 대신 SHA-256 해시만). XE1 모듈 Tokens 와 같은 동작.
 */
class Store
{
    const ACCESS_TTL = 3600;
    const REFRESH_TTL = 31536000;

    public static function tablesExist()
    {
        return Schema::hasTable('appapi_ids') && Schema::hasTable('appapi_tokens');
    }

    public static function ensureTables()
    {
        if (!Schema::hasTable('appapi_ids')) {
            Schema::create('appapi_ids', function (Blueprint $t) {
                $t->increments('id');
                $t->string('uuid', 64)->unique();
            });
        }
        if (!Schema::hasTable('appapi_tokens')) {
            Schema::create('appapi_tokens', function (Blueprint $t) {
                $t->increments('token_id');
                $t->string('user_id', 64)->index();
                $t->char('access_hash', 64)->unique();
                $t->unsignedInteger('access_expires');
                $t->char('refresh_hash', 64)->unique();
                $t->char('prev_refresh_hash', 64)->nullable()->index();
                $t->unsignedInteger('refresh_expires');
                $t->char('password_sig', 64);
                $t->string('device_name', 100)->default('');
                $t->string('platform', 20)->default('');
                $t->string('ipaddress', 64)->default('');
                $t->unsignedInteger('created');
                $t->unsignedInteger('last_used');
            });
        }
    }

    // ---- UUID ↔ 정수

    private static $num = [];
    private static $uuid = [];

    /** UUID 의 정수 번호 (처음 보면 만든다). 빈 값은 0 */
    public static function num($uuid)
    {
        $uuid = (string)$uuid;
        if ($uuid === '') {
            return 0;
        }
        if (!isset(self::$num[$uuid])) {
            $id = DB::table('appapi_ids')->where('uuid', $uuid)->value('id');
            if (!$id) {
                try {
                    $id = DB::table('appapi_ids')->insertGetId(['uuid' => $uuid]);
                } catch (\Illuminate\Database\QueryException $e) { // 동시에 만들어진 경우
                    $id = DB::table('appapi_ids')->where('uuid', $uuid)->value('id');
                }
            }
            self::$num[$uuid] = (int)$id;
            self::$uuid[(int)$id] = $uuid;
        }
        return self::$num[$uuid];
    }

    /** 정수 번호의 UUID (없으면 null) */
    public static function uuid($num)
    {
        $num = (int)$num;
        if ($num <= 0) {
            return null;
        }
        if (!array_key_exists($num, self::$uuid)) {
            self::$uuid[$num] = DB::table('appapi_ids')->where('id', $num)->value('uuid');
        }
        return self::$uuid[$num];
    }

    // ---- 토큰

    public static function passwordSig($passwordHash)
    {
        return hash('sha256', 'appapi|' . $passwordHash);
    }

    private static function newToken()
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    private static function hash($token)
    {
        return hash('sha256', (string)$token);
    }

    private static function output($access, $refresh)
    {
        return [
            'access_token' => $access,
            'access_expires_in' => self::ACCESS_TTL,
            'refresh_token' => $refresh,
            'refresh_expires_in' => self::REFRESH_TTL,
        ];
    }

    public static function issue($userId, $passwordHash, $deviceName, $platform, $ip)
    {
        $access = self::newToken();
        $refresh = self::newToken();
        $now = time();
        DB::table('appapi_tokens')->insert([
            'user_id' => $userId,
            'access_hash' => self::hash($access), 'access_expires' => $now + self::ACCESS_TTL,
            'refresh_hash' => self::hash($refresh), 'refresh_expires' => $now + self::REFRESH_TTL,
            'password_sig' => self::passwordSig($passwordHash),
            'device_name' => mb_substr((string)$deviceName, 0, 100), 'platform' => mb_substr((string)$platform, 0, 20),
            'ipaddress' => (string)$ip, 'created' => $now, 'last_used' => $now,
        ]);
        if (mt_rand(1, 50) === 1) {
            DB::table('appapi_tokens')->where('refresh_expires', '<', $now)->delete();
        }
        return self::output($access, $refresh);
    }

    /** 유효한 접근 토큰의 행 (만료·없음이면 null) */
    public static function findByAccess($access)
    {
        $row = DB::table('appapi_tokens')->where('access_hash', self::hash($access))->first();
        return ($row && $row->access_expires >= time()) ? $row : null;
    }

    /** 새 접근 토큰이 처음 쓰였으니 직전 갱신 토큰은 더 받지 않는다 */
    public static function touch($row)
    {
        $now = time();
        if ($row->prev_refresh_hash !== null || $row->last_used < $now - 60) {
            DB::table('appapi_tokens')->where('token_id', $row->token_id)->update(['last_used' => $now, 'prev_refresh_hash' => null]);
        }
    }

    /**
     * 갱신 토큰으로 새 쌍을 발급 (회전). 응답이 유실돼도 로그아웃되지 않게, 새 접근 토큰이 처음 쓰일 때까지 직전 갱신 토큰도 받는다.
     * @return array|null [행, 새 토큰]
     */
    public static function rotate($refresh, $ip)
    {
        $hash = self::hash($refresh);
        $row = DB::table('appapi_tokens')->where('refresh_hash', $hash)->orWhere('prev_refresh_hash', $hash)->first();
        if (!$row || $row->refresh_expires < time()) {
            return null;
        }
        $access = self::newToken();
        $newRefresh = self::newToken();
        $now = time();
        DB::table('appapi_tokens')->where('token_id', $row->token_id)->update([
            'access_hash' => self::hash($access), 'access_expires' => $now + self::ACCESS_TTL,
            'refresh_hash' => self::hash($newRefresh), 'prev_refresh_hash' => $row->refresh_hash,
            'refresh_expires' => $now + self::REFRESH_TTL, 'ipaddress' => (string)$ip, 'last_used' => $now,
        ]);
        return [$row, self::output($access, $newRefresh)];
    }

    public static function revoke($tokenId)
    {
        DB::table('appapi_tokens')->where('token_id', $tokenId)->delete();
    }

    /** 이 회원의 로그인한 기기 (1.0.19~, auth.devices). 해시·IP 는 내보내지 않는다 */
    public static function devices($userId)
    {
        return DB::table('appapi_tokens')->where('user_id', $userId)->where('refresh_expires', '>=', time())
            ->orderBy('last_used', 'desc')->orderBy('token_id', 'desc')
            ->get(['token_id', 'device_name', 'platform', 'created', 'last_used'])->all();
    }

    /** 이 회원의 토큰 줄만 지운다. 지웠으면 true */
    public static function revokeOwn($userId, $tokenId)
    {
        return DB::table('appapi_tokens')->where('token_id', (int)$tokenId)->where('user_id', $userId)->delete() > 0;
    }

    public static function revokeUser($userId)
    {
        DB::table('appapi_tokens')->where('user_id', $userId)->delete();
    }
}
