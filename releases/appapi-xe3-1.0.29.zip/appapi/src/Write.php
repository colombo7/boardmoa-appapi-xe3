<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use XeDB;
use XeEditor;
use XeMedia;
use XeStorage;
use Xpressengine\Editor\EditorHandler;
use Xpressengine\Permission\Instance;
use Xpressengine\Plugins\Board\BoardPermissionHandler;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Comment\Models\Comment;

/**
 * 쓰기: 글·댓글 쓰기·고치기·지우기, 추천·스크랩·신고.
 * 웹 화면(BoardModuleController·댓글 UserController)과 같은 판단(권한 Gate, 본인 확인, 비밀글·공지 설정)을 하고,
 * 실제 저장은 엔진의 서비스·핸들러(BoardService::store 등)에 맡긴다. 그래서 이벤트(알림·포인트 등)도 웹과 같다.
 */
class Write
{
    const MAX_PHOTOS = 30;

    /** 읽을 수 있는 게시판 [메뉴 항목, 설정]. 못 읽으면 없는 게시판처럼 */
    private static function board()
    {
        $item = \XeMenu::items()->query()->where('url', (string)Api::param('mid'))->first();
        $config = $item && $item->type === Boards::BOARD ? app('xe.board.config')->get($item->id) : null;
        if (!$config || !Boards::grant($item->id)['list']) {
            throw new ApiError(404, 'board_not_found', '없는 게시판입니다.');
        }
        return [$item, $config];
    }

    private static function perm($instanceId)
    {
        return new Instance(app(BoardPermissionHandler::class)->name($instanceId));
    }

    private static function denied()
    {
        // 비회원이면 401: 앱이 로그인을 권한다
        return new ApiError(Auth::check() ? 403 : 401, 'not_permitted', Api::message('not_permitted'));
    }

    /** 앱은 일반 글자로 보낸다: 태그는 글자로, 줄바꿈은 살린다 */
    private static function textToHtml($text)
    {
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)$text));
        if ($text === '') {
            return '';
        }
        return '<p>' . nl2br(htmlspecialchars(mb_substr($text, 0, 50000), ENT_QUOTES, 'UTF-8')) . '</p>';
    }

    /** 앱 꾸밈 편집기의 HTML. 글자·사진이 없으면(빈 줄만) 빈 본문 */
    private static function editorHtml($html)
    {
        $html = trim((string)$html);
        if (trim(str_replace(['&nbsp;', "\xC2\xA0"], ' ', strip_tags($html, '<img><video><iframe>'))) === '') {
            return '';
        }
        return mb_substr($html, 0, 500000);
    }

    /** 웹처럼 HTML 정리 (관리자는 원문 그대로) */
    private static function purify($html, $manager)
    {
        if ($manager) {
            return $html;
        }
        $purifier = new \Xpressengine\Support\Purifier();
        $purifier->allowModule(\Xpressengine\Editor\PurifierModules\EditorContent::class);
        $purifier->allowModule(\Xpressengine\Support\PurifierModules\Html5::class);
        return $purifier->purify($html);
    }

    /** 이 게시판 글 하나 (UUID) */
    private static function document($item)
    {
        $uuid = Store::uuid(Api::intParam('document_srl'));
        $doc = $uuid ? Board::division($item->id)->find($uuid) : null;
        if (!$doc || $doc->instance_id !== $item->id) {
            throw new ApiError(404, 'document_not_found', '없는 글입니다.');
        }
        return $doc;
    }

    /** 작성자 본인이거나 관리 권한 (웹 hasItemPerm 과 같은 판단) */
    private static function editable(Board $doc, $item)
    {
        // 엔진 hasItemPerm 과 같은 뜻이지만 비회원끼리 느슨하게 같아지지 않게 (Boards::owns)
        if (!Boards::owns($doc, Boards::grant($item->id)['manager'])) {
            throw self::denied();
        }
    }

    // ---- 사진

    /** multipart photos[] — 정상 업로드인 JPEG 만 */
    private static function photos()
    {
        $files = Api::$request->file('photos');
        if ($files === null) {
            return [];
        }
        $files = is_array($files) ? array_values($files) : [$files];
        if (count($files) > self::MAX_PHOTOS) {
            throw new ApiError(400, 'too_many_photos', '사진은 한 번에 30장까지 올릴 수 있습니다.');
        }
        foreach ($files as $file) {
            if (!$file->isValid()) {
                throw new ApiError(400, 'upload_failed', '사진을 올리지 못했습니다.');
            }
        }
        return $files;
    }

    /** 웹 에디터의 파일 올리기(EditorController::fileUpload)와 같은 검사·저장. [본문에 붙일 HTML, 파일 id 들]. $first: 첫 사진 번호(고치기는 이미 붙은 파일 다음) */
    private static function uploadPhotos($instanceId, array $photos, $first = 1)
    {
        $editor = XeEditor::get($instanceId);
        $config = $editor->getConfig();
        if (!$config->get('uploadActive') || Gate::denies('upload', Boards::editorPerm($instanceId))) {
            throw new ApiError(403, 'not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        // 앱은 사진을 photoN.jpg 로 보낸다: 웹 에디터처럼 허용 확장자(jpg)를 보고, 이름만 바꾼 다른 파일이 아닌 실제 JPEG 그림인지 확인한다 (하나라도 아니면 하나도 올리지 않는다)
        $extensions = array_map('trim', explode(',', strtolower((string)$config->get('extensions', ''))));
        if (!in_array('*', $extensions, true) && !in_array('jpg', $extensions, true) && !in_array('jpeg', $extensions, true)) {
            throw new ApiError(403, 'not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        foreach ($photos as $photo) {
            $info = @getimagesize((string)$photo->getRealPath());
            if (!$info || (int)$info[2] !== IMAGETYPE_JPEG) {
                throw new ApiError(400, 'upload_failed', '사진을 올리지 못했습니다.');
            }
        }
        $width = (string)Api::param('photo_width', 'full');
        $style = $width === 'half' ? 'width:50%;height:auto;' : ($width === 'original' ? 'max-width:100%;height:auto;' : 'width:100%;height:auto;');
        $html = '';
        $ids = [];
        foreach ($photos as $index => $photo) {
            if ($config->get('fileMaxSize') * 1024 * 1024 < $photo->getSize() && !$editor->isPrivileged()) {
                throw new ApiError(413, 'file_too_large', Text::t('사진이 이 게시판의 파일 크기 한도({0}MB)를 넘습니다.', $config->get('fileMaxSize')));
            }
            Points::beforeUpload($instanceId); // 포인트 플러그인의 편집기 파일 올리기 판단 (웹과 같게)
            $name = 'photo' . ($first + $index) . '.jpg';
            $file = XeStorage::upload($photo, EditorHandler::FILE_UPLOAD_PATH, $name);
            Points::uploaded($instanceId);
            if (XeMedia::is($file)) {
                XeMedia::createThumbnails(XeMedia::make($file), EditorHandler::THUMBNAIL_TYPE);
            }
            $ids[] = $file->id;
            $url = htmlspecialchars(Boards::absolute($file->url()), ENT_QUOTES, 'UTF-8');
            $html .= '<p><img class="__xe_image" data-id="' . $file->id . '" xe-file-id="' . $file->id . '" src="' . $url . '" alt="' . $name . '" style="' . $style . '" /></p>';
        }
        return [$html, $ids];
    }

    /** multipart files[] (사진이 아닌 파일 첨부, 1.0.18~ 기능 file_upload) — 정상 업로드만 */
    private static function attachments()
    {
        $files = Api::$request->file('files');
        if ($files === null) {
            return [];
        }
        $files = is_array($files) ? array_values($files) : [$files];
        if (count($files) > self::MAX_PHOTOS) {
            throw new ApiError(400, 'upload_failed', '파일은 한 번에 30개까지 올릴 수 있습니다.');
        }
        foreach ($files as $file) {
            if (!$file instanceof \Illuminate\Http\UploadedFile || !$file->isValid()) {
                throw new ApiError(400, 'upload_failed', '파일을 올리지 못했습니다.');
            }
        }
        return $files;
    }

    /**
     * 파일 첨부를 올리기 전 확인 (웹 에디터 파일 올리기 EditorController::fileUpload 와 같은 권한·크기·허용 확장자, 엔진 문구 그대로).
     * 웹 화면이 막는 전체 크기 한도(attachMaxSize, 이미 붙은 파일 포함)도 본다. 모두 확인한 뒤에 올린다(하나라도 안 되면 하나도 올리지 않는다)
     */
    private static function checkAttachments($instanceId, array $files, $existingSize = 0, array $photos = [])
    {
        if (!$files) {
            return;
        }
        $editor = XeEditor::get($instanceId);
        $config = $editor->getConfig();
        if (!$config->get('uploadActive') || Gate::denies('upload', Boards::editorPerm($instanceId))) {
            throw new ApiError(403, 'upload_not_permitted', '이 게시판에는 파일을 올릴 수 없습니다.');
        }
        $privileged = $editor->isPrivileged();
        $extensions = array_map('trim', explode(',', (string)$config->get('extensions', '')));
        $total = (int)$existingSize;
        foreach ($photos as $photo) {
            $total += (int)$photo->getSize();
        }
        foreach ($files as $file) {
            if ($config->get('fileMaxSize') * 1024 * 1024 < $file->getSize() && !$privileged) {
                throw new ApiError(400, 'upload_failed', (string)xe_trans('xe::msgMaxFileSize', ['fileMaxSize' => $config->get('fileMaxSize'), 'uploadFileName' => $file->getClientOriginalName()]));
            }
            if (array_search('*', $extensions) === false && !in_array(strtolower($file->getClientOriginalExtension()), $extensions)) {
                throw new ApiError(400, 'upload_failed', (string)xe_trans('xe::msgAvailableUploadingFiles', ['extensions' => $config->get('extensions'), 'uploadFileName' => $file->getClientOriginalName()]));
            }
            $total += (int)$file->getSize();
        }
        if (!$privileged && (float)$config->get('attachMaxSize') > 0 && $config->get('attachMaxSize') * 1024 * 1024 < $total) {
            throw new ApiError(400, 'upload_failed', Text::t('첨부 파일이 이 게시판의 전체 크기 한도({0}MB)를 넘습니다.', $config->get('attachMaxSize')));
        }
    }

    /** 확인한 파일을 웹 에디터와 같이 저장한다(원래 파일 이름, 같은 저장 경로·썸네일·올리기 포인트). 파일 id 들 — 본문에는 넣지 않고 글 첨부로 붙인다 */
    private static function uploadAttachments($instanceId, array $files)
    {
        $ids = [];
        foreach ($files as $file) {
            Points::beforeUpload($instanceId);
            $stored = XeStorage::upload($file, EditorHandler::FILE_UPLOAD_PATH);
            Points::uploaded($instanceId);
            if (XeMedia::is($stored)) {
                XeMedia::createThumbnails(XeMedia::make($stored), EditorHandler::THUMBNAIL_TYPE);
            }
            $ids[] = $stored->id;
        }
        return $ids;
    }

    // ---- 글

    /** 비회원이 쓸 수 없을 때: 예전(토큰 필수)처럼 401 login_required — 앱이 로그인을 권한다 */
    private static function loginRequired()
    {
        return new ApiError(401, 'login_required', Api::message('login_required'));
    }

    /**
     * 이 게시판에 글을 쓰려면 CAPTCHA 를 풀어야 하는가 (게시판 설정 '캡차 사용', 엔진 BoardService::checkCaptcha 와 같은 판단 — 회원·비회원 모두).
     * 사이트 CAPTCHA 가 reCAPTCHA v2 면 앱이 풀어 captcha_response 로 보낸다(1.0.18~, 기능 captcha_solve). 아니면 웹으로 안내한다
     */
    public static function captchaRequired($config)
    {
        return $config && $config->get('useCaptcha', false) === true;
    }

    /**
     * 403 captcha_required (XE·Rhymix 모듈과 같은 코드). error.captcha: 앱이 풀 수 있는 reCAPTCHA v2 면 위젯 정보(1.0.18~),
     * 아니면 null — 앱이 풀 위젯이 없으니 웹으로 안내한다(문구도 예전 그대로)
     */
    private static function captchaError()
    {
        if (Captcha::widget() === null) {
            return new ApiError(403, 'captcha_required', '이 게시판은 글을 쓸 때 자동 입력 방지 확인을 거쳐야 해서 앱에서는 쓸 수 없습니다. 웹에서 써 주세요.', ['captcha' => null]);
        }
        return Captcha::error(Api::param('captcha_response') ? '자동 입력 방지 확인을 통과하지 못했습니다. 다시 해 주세요.' : '자동 입력 방지 확인이 필요합니다.');
    }

    public static function insertDocument()
    {
        // 비회원 (0.3.4~, 기능 guest_write): 쓸 수 없는 게시판이면 예전처럼 401 login_required (not_permitted 가 아니라)
        $guest = !Auth::check();
        try {
            list($item, $config) = self::board();
        } catch (ApiError $e) {
            throw $guest ? self::loginRequired() : $e;
        }
        if (Gate::denies(BoardPermissionHandler::ACTION_CREATE, self::perm($item->id))) {
            throw $guest ? self::loginRequired() : self::denied();
        }
        // 상담 게시판은 비회원이 글을 쓸 수 없다 (웹 BoardModuleController::create·store 와 같다)
        if ($guest && $config->get('useConsultation') === true) {
            throw self::loginRequired();
        }
        // CAPTCHA 는 사진을 올리기 전에 본다: 예전에는 사진을 올린 뒤 엔진이 거절해 파일이 남고 올리기 포인트가 빠졌다.
        // 앱이 푼 답은 웹 양식 이름(g-recaptcha-response)으로 넣고 코어 드라이버가 확인한다. 엔진의 store 도 같은 드라이버로 다시 확인한다(결과를 기억해 구글에 두 번 묻지 않는다)
        if (self::captchaRequired($config) && !Captcha::verify()) {
            throw self::captchaError();
        }
        $title = trim((string)Api::param('title', ''));
        // content_format=html: 앱 꾸밈 편집기의 HTML (아래 purify 로 웹처럼 정리). 없으면(예전 앱) 일반 글자
        $content = Api::param('content_format') === 'html' ? self::editorHtml(Api::param('content', '')) : self::textToHtml(Api::param('content', ''));
        $photos = self::photos();
        if ($title === '' || ($content === '' && !$photos)) {
            throw new ApiError(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $secret = (bool)Api::param('is_secret');
        if ($secret && $config->get('secretPost') !== true) {
            throw new ApiError(403, 'not_permitted', '이 게시판은 비밀글을 쓸 수 없습니다.');
        }
        // 비회원: 웹 글쓰기와 같은 항목·규칙(게시판 Validator::guestStore — 이름 2자 이상, 메일, 비밀번호 4~64자). 사진보다 먼저 확인한다
        $guest = Auth::check() ? null : self::guestInputs();
        // 추가 항목(확장 필드, 1.0.18~): 웹 글쓰기와 같은 항목 규칙(필수 등)으로 사진보다 먼저 확인한다
        list($fieldValues) = Fields::inputs($config);
        // 파일 첨부(1.0.18~, 기능 file_upload): 사진보다 먼저 모두 확인한다
        $attachments = self::attachments();
        self::checkAttachments($item->id, $attachments, 0, $photos);
        $editor = XeEditor::get($item->id);
        $fileIds = [];
        if ($photos) {
            list($html, $fileIds) = self::uploadPhotos($item->id, $photos);
            $content .= $html;
        }
        $fileIds = array_merge($fileIds, self::uploadAttachments($item->id, $attachments));
        $inputs = [
            'title' => htmlspecialchars(mb_substr($title, 0, 180), ENT_COMPAT | ENT_HTML401, 'UTF-8', false),
            'content' => self::purify($content, Boards::grant($item->id)['manager']),
            'display' => $secret ? Board::DISPLAY_SECRET : Board::DISPLAY_VISIBLE,
            'allow_comment' => 1,
            'use_alarm' => 1,
            'slug' => \Xpressengine\Plugins\Board\Models\BoardSlug::convert('', $title),
            $editor->getFileInputName() => $fileIds,
        ];
        if ($category = Api::intParam('category_srl')) {
            $inputs['category_item_id'] = $category;
        }
        if ($guest) {
            // certify_key 는 엔진(BoardService::store)이 암호로 바꿔 저장한다. 웹에서 그 글을 고치거나 지울 때 메일·비밀번호로 확인한다
            $inputs = array_merge($inputs, $guest);
        }
        // 확장 필드 값은 웹 양식과 같은 이름(<항목 id>_<칸>)으로: 엔진(DynamicField 프록시)이 글과 함께 저장한다
        $inputs = array_merge($inputs, $fieldValues);
        $request = Request::create(Api::$request->url(), 'POST', $inputs);
        $request->setUserResolver(function () { return Auth::user(); });
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        try {
            $doc = $service->store($request, Auth::user(), $config, app('xe.board.identify'));
        } catch (\Xpressengine\Plugins\Board\Exceptions\CaptchaNotVerifiedException $e) {
            throw self::captchaError();
        }
        return ['document_srl' => Store::num($doc->id)];
    }

    /** 비회원 글의 이름·메일·비밀번호 (웹 글쓰기 화면의 writer·email·certify_key, 같은 검사 규칙) */
    private static function guestInputs()
    {
        $inputs = [
            'writer' => trim((string)Api::param('nick_name', '')),
            'email' => trim((string)Api::param('email_address', '')),
            'certify_key' => (string)Api::param('password', ''),
        ];
        if ($inputs['writer'] === '' || $inputs['email'] === '' || $inputs['certify_key'] === '') {
            throw new ApiError(400, 'guest_info_required', '이름·메일·비밀번호를 입력해 주세요.');
        }
        $rules = app(\Xpressengine\Plugins\Board\Validator::class)->guestStore();
        unset($rules['slug']); // 제목으로 만든다 (아래 slug)
        $validator = \Validator::make($inputs, $rules, [], ['writer' => Text::t('이름'), 'email' => Text::t('메일'), 'certify_key' => Text::t('비밀번호')]);
        if ($validator->fails()) {
            throw new ApiError(400, 'invalid_guest_info', $validator->errors()->first());
        }
        return $inputs;
    }

    /** 로그인하지 않았는데 비밀번호도 없으면 예전(토큰 필수)처럼 401 login_required. 게시판을 찾기 전에 본다 */
    private static function guestPassword()
    {
        if (!Auth::check()) {
            Guest::requirePassword();
        }
    }

    /**
     * 로그인하지 않았으면 비회원 글의 메일·비밀번호로 확인한다 (웹 guestCertify 와 같은 확인, 이번 요청만).
     * 그 뒤 고칠 권한은 웹과 같은 hasItemPerm(editable)이 판단한다. 회원은 토큰으로만 판단한다(비밀번호는 보지 않는다)
     */
    private static function guestAccess(Board $doc)
    {
        if (!Auth::check()) {
            Guest::certifyDocument($doc, Guest::requirePassword());
        }
    }

    /** 고칠 글의 원본 HTML (고칠 수 있는 사람에게만) */
    public static function documentSource()
    {
        self::guestPassword();
        list($item, $config) = self::board();
        $doc = self::document($item);
        self::guestAccess($doc);
        self::editable($doc, $item);
        return [
            'document_srl' => Store::num($doc->id),
            'title' => html_entity_decode((string)$doc->title, ENT_QUOTES, 'UTF-8'),
            'content' => (string)$doc->content,
            'base_url' => rtrim(url('/'), '/') . '/',
            // XE3 는 제목 굵게·색이 없다. 공지만 관리자가 바꾼다
            'manage' => Boards::grant($item->id)['manager']
                ? ['is_notice' => (int)$doc->status === Board::STATUS_NOTICE, 'title_bold' => false, 'title_color' => '']
                : null,
            // 이 글에 사진을 더 붙일 수 있는지와 한도 (0.3.4~, 기능 edit_photos): 글쓰기와 같은 판단. 1.0.18~ 파일 첨부(files)도
            'upload' => Boards::uploadInfo($item->id, Boards::grant($item->id)),
            // 추가 항목(확장 필드) 정의와 지금 값 (1.0.18~, 기능 extra_vars, board.extra_keys 와 같은 꼴)
            'extra_keys' => Fields::keys($config),
            'extra_values' => Fields::values($doc, $config),
        ];
    }

    public static function updateDocument()
    {
        self::guestPassword();
        list($item, $config) = self::board();
        $doc = self::document($item);
        self::guestAccess($doc);
        self::editable($doc, $item);
        $manager = Boards::grant($item->id)['manager'];
        $title = trim((string)Api::param('title', ''));
        $content = (string)Api::param('content', '');
        // 새로 붙일 사진 (0.3.4~, 기능 edit_photos): 글쓰기와 같은 multipart photos[]
        $photos = self::photos();
        if ($title === '' || (trim(strip_tags($content, '<img>')) === '' && !$photos)) {
            throw new ApiError(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        // 추가 항목(확장 필드, 1.0.18~): 보낸 항목만 바꾼다. 보내지 않으면(예전 앱) 그대로
        list($fieldValues) = Fields::inputs($config, $doc);
        // 파일 첨부 더하기 (1.0.18~, 기능 file_upload): 지우기는 웹에서. 이미 붙은 파일 크기까지 전체 한도에 센다
        $attachments = self::attachments();
        self::checkAttachments($item->id, $attachments, (int)$doc->files->sum('size'), $photos);
        $editor = XeEditor::get($item->id);
        $newIds = [];
        if ($photos) {
            // 웹 에디터처럼 올린 파일 id 를 글의 파일 목록에 더하면 엔진이 글에 붙인다 (올리기 권한·크기 검사는 글쓰기와 같다)
            list($html, $newIds) = self::uploadPhotos($item->id, $photos, $doc->files->count() + 1);
            $content .= $html;
        }
        $newIds = array_merge($newIds, self::uploadAttachments($item->id, $attachments));
        // 엔진의 고치기는 보낸 값으로 덮으므로 원래 값(비밀글·공지·분류·댓글 허용·첨부)을 채워 보낸다
        $notice = $manager && Api::param('is_notice') !== null ? (bool)Api::param('is_notice') && Api::param('is_notice') !== 'N' : (int)$doc->status === Board::STATUS_NOTICE;
        $fileIds = array_merge($doc->files->pluck('id')->all(), $newIds);
        $inputs = [
            'id' => $doc->id,
            'title' => htmlspecialchars(mb_substr($title, 0, 180), ENT_COMPAT | ENT_HTML401, 'UTF-8', false),
            'content' => self::purify($content, $manager),
            'display' => (int)$doc->display === Board::DISPLAY_SECRET ? Board::DISPLAY_SECRET : Board::DISPLAY_VISIBLE,
            'status' => $notice ? Board::STATUS_NOTICE : Board::STATUS_PUBLIC,
            'allow_comment' => (int)($doc->boardData->allow_comment ?? 1),
            'use_alarm' => (int)($doc->boardData->use_alarm ?? 1),
            'slug' => $doc->boardSlug->slug ?? \Xpressengine\Plugins\Board\Models\BoardSlug::convert('', $title),
            'category_item_id' => $doc->boardCategory->item_id ?? null,
            $editor->getFileInputName() => $fileIds,
        ];
        if ($doc->isGuest()) {
            // 웹 고치기 화면처럼 비회원 이름·메일을 그대로 보낸다. 비밀번호(certify_key)는 보내지 않아 엔진이 원래 값을 둔다
            $inputs['writer'] = (string)$doc->writer;
            $inputs['email'] = (string)$doc->email;
        }
        $request = Request::create(Api::$request->url(), 'POST', array_filter($inputs, function ($v) { return $v !== null; }));
        $request->setUserResolver(function () { return Auth::user(); });
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $doc = $service->update($doc, $request, Auth::user(), $config, app('xe.board.identify'));
        Fields::save($doc, $config, $fieldValues);
        return ['document_srl' => Store::num($doc->id)];
    }

    public static function deleteDocument()
    {
        self::guestPassword();
        list($item, $config) = self::board();
        $doc = self::document($item);
        self::guestAccess($doc);
        self::editable($doc, $item);
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $service->destroy($doc, $config, app('xe.board.identify'));
        return ['deleted' => true];
    }

    // ---- 댓글

    private static function commentHandler()
    {
        return app('xe.plugin.comment')->getHandler();
    }

    public static function insertComment()
    {
        // 비회원 (0.3.5~, 기능 guest_comment): 이름도 비밀번호도 없으면 예전(토큰 필수)처럼 401 login_required
        if (!Auth::check() && trim((string)Api::param('nick_name', '')) === '' && (string)Api::param('password', '') === '') {
            throw new ApiError(401, 'login_required', Api::message('login_required'));
        }
        list($item, $config) = self::board();
        $doc = self::document($item);
        $grant = Boards::grant($item->id);
        if (!$grant['view'] && $doc->user_id !== Auth::id()) {
            throw self::denied();
        }
        // 상담 게시판은 자기 글만 열린다 (웹 show 와 같다)
        if ($config->get('useConsultation') === true && !Boards::owns($doc, $grant['manager'])) {
            throw self::denied();
        }
        // 비밀번호로 연 비회원 비밀글 (기능 unlocked_comment): 웹처럼 그 글의 메일·비밀번호로 이번 요청에서 연다
        // (password·email_address 는 새 비회원 댓글의 것이라, 글은 document_password·document_email 로 받는다)
        $documentPassword = (string)Api::param('document_password', '');
        if (!Auth::check() && $documentPassword !== '') {
            Guest::certifyDocument($doc, $documentPassword, 'document_email');
        }
        // 웹은 글 화면(BoardService::getItem 이 통과해야 열린다)에서 댓글을 쓴다: 읽을 수 없는 비밀글·미승인 글에는 못 쓴다
        try {
            app(\Xpressengine\Plugins\Board\Services\BoardService::class)->getItem($doc->id, Auth::user(), $config, $grant['manager']);
        } catch (\Exception $e) {
            throw self::denied();
        }
        $handler = self::commentHandler();
        $instanceId = $handler->getInstanceId($item->id);
        if (!$instanceId || $config->get('comment') !== true || (int)($doc->boardData->allow_comment ?? 1) !== 1
            || Gate::denies('create', new Instance($handler->getKeyForPerm($instanceId)))) {
            throw new ApiError(403, 'not_permitted', '댓글을 쓸 수 없습니다.');
        }
        $content = self::textToHtml(Api::param('content', ''));
        if ($content === '') {
            throw new ApiError(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $inputs = [
            'instance_id' => $instanceId,
            'target_id' => $doc->id,
            'target_type' => Board::class,
            'target_author_id' => $doc->getAuthor()->getId(),
            'content' => self::purify($content, false),
            'format' => XeEditor::get($instanceId)->htmlable() ? Comment::FORMAT_HTML : Comment::FORMAT_NONE,
            'display' => Api::param('is_secret') ? Comment::DISPLAY_SECRET : Comment::DISPLAY_VISIBLE,
        ];
        if (!Auth::check()) {
            $inputs = array_merge($inputs, self::guestCommentInputs());
        }
        if ($parent = Store::uuid(Api::intParam('parent_srl'))) {
            $parentComment = $handler->createModel($instanceId)->newQuery()->where('id', $parent)->first();
            if (!$parentComment || $parentComment->target->target_id !== $doc->id) {
                throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
            }
            $inputs['parent_id'] = $parent;
        }
        \Event::dispatch('xe.plugin.comment.create', [Request::create(Api::$request->url(), 'POST', $inputs)]);
        $comment = $handler->create($inputs, Auth::user());
        return ['comment_srl' => Store::num($comment->id), 'document_srl' => Store::num($doc->id)];
    }

    /** 비회원 댓글의 이름·메일·비밀번호 (웹 댓글 쓰기 UserController::store 와 같은 항목·규칙, 비밀번호는 같은 bcrypt) */
    private static function guestCommentInputs()
    {
        $inputs = [
            'writer' => trim((string)Api::param('nick_name', '')),
            'email' => trim((string)Api::param('email_address', '')),
            'certify_key' => (string)Api::param('password', ''),
        ];
        if ($inputs['writer'] === '' || $inputs['email'] === '' || $inputs['certify_key'] === '') {
            throw new ApiError(400, 'guest_info_required', '이름·메일·비밀번호를 입력해 주세요.');
        }
        $rules = [
            'email' => 'Required|Between:3,64|Email',
            'writer' => 'Required|Between:3,32',
            'certify_key' => 'Required|AlphaNum|Between:4,8',
        ];
        $validator = \Validator::make($inputs, $rules, [], ['writer' => Text::t('이름'), 'email' => Text::t('메일'), 'certify_key' => Text::t('비밀번호')]);
        if ($validator->fails()) {
            throw new ApiError(400, 'invalid_guest_info', $validator->errors()->first());
        }
        $inputs['certify_key'] = bcrypt($inputs['certify_key']);
        return $inputs;
    }

    /** 이 게시판의 댓글 하나 */
    private static function comment($item)
    {
        $handler = self::commentHandler();
        $instanceId = $handler->getInstanceId($item->id);
        $uuid = Store::uuid(Api::intParam('comment_srl'));
        $comment = ($instanceId && $uuid) ? $handler->createModel($instanceId)->newQuery()->where('instance_id', $instanceId)->where('id', $uuid)->first() : null;
        if (!$comment) {
            throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
        }
        // 로그인하지 않았으면 비회원 댓글의 메일·비밀번호로 확인한다 (웹 댓글 certify 와 같은 확인, 이번 요청만)
        if (!Auth::check()) {
            Guest::certifyComment($comment, Guest::requirePassword());
        }
        return $comment;
    }

    /** 댓글 고치기 (0.3.5~, 기능 comment_edit): 웹 UserController::update 와 같은 판단(CommentPolicy update)·같은 저장(Handler::put) */
    public static function updateComment()
    {
        self::guestPassword();
        list($item) = self::board();
        $comment = self::comment($item);
        if (Gate::denies('update', $comment)) {
            throw self::denied();
        }
        $content = self::textToHtml(Api::param('content', ''));
        if ($content === '') {
            throw new ApiError(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $handler = self::commentHandler();
        // 내용만 바꾼다: 비밀 댓글 여부·이름·메일·비밀번호·첨부는 그대로 (웹은 폼에 원래 값을 채워 보낸다)
        $comment->content = self::purify($content, false);
        $comment->format = XeEditor::get($comment->instance_id)->htmlable() ? Comment::FORMAT_HTML : Comment::FORMAT_NONE;
        $comment = $handler->put($comment);
        return ['comment_srl' => Store::num($comment->id), 'document_srl' => Store::num($comment->target->target_id)];
    }

    public static function deleteComment()
    {
        self::guestPassword();
        list($item) = self::board();
        $handler = self::commentHandler();
        $comment = self::comment($item);
        // 웹과 같은 판단: 댓글 정책(CommentPolicy) 의 delete
        if (Gate::denies('delete', $comment)) {
            throw self::denied();
        }
        $trashed = $handler->trash($comment);
        if ($trashed && (int)$trashed->display !== Comment::DISPLAY_VISIBLE && $comment->getAuthor()->getId() === Auth::id()) {
            $handler->remove($trashed);
        }
        return ['deleted' => true];
    }

    /**
     * 댓글 추천 (1.0.18~, 기능 comment_vote): 웹 댓글 단추(UserController::voteOn·voteOff)와 같은 핸들러(addVote·removeVote).
     * 웹처럼 회원만(비회원은 웹에서도 추천되지 않는다), 댓글 설정의 추천·비추천 사용일 때만. 글·댓글을 볼 수 없으면 막는다(웹 단추는 글 화면에만 있다).
     * 같은 것을 이미 눌렀으면 400 vote_failed (cancel 이면 취소)
     */
    public static function commentVote()
    {
        if (!Auth::check()) {
            throw new ApiError(401, 'login_required', Api::message('login_required'));
        }
        list($item, $config) = self::board();
        $handler = self::commentHandler();
        $instanceId = $handler->getInstanceId($item->id);
        $uuid = Store::uuid(Api::intParam('comment_srl'));
        $comment = ($instanceId && $uuid) ? $handler->createModel($instanceId)->newQuery()->where('instance_id', $instanceId)->where('id', $uuid)->first() : null;
        if (!$comment) {
            throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
        }
        Boards::readableComment($item, $config, $comment);
        $voteConfig = Boards::commentVoteConfig($handler->getConfig($instanceId));
        $option = (int)Api::param('point', 1) < 0 ? 'dissent' : 'assent';
        if (!$voteConfig[$option]) {
            throw new ApiError(403, 'not_permitted', $option === 'assent' ? '이 게시판은 댓글 추천을 쓰지 않습니다.' : '이 게시판은 댓글 비추천을 쓰지 않습니다.');
        }
        $cancel = (bool)Api::param('cancel') && Api::param('cancel') !== 'N';
        XeDB::beginTransaction();
        try {
            $done = $cancel ? $handler->removeVote($comment, $option, Auth::user()) : $handler->addVote($comment, $option, Auth::user());
        } catch (\Exception $e) {
            XeDB::rollBack();
            throw $e;
        }
        XeDB::commit();
        if (!$done) {
            throw new ApiError(400, 'vote_failed', $cancel ? '취소할 추천이 없습니다.' : ($option === 'assent' ? '이미 추천했습니다.' : '이미 비추천했습니다.'));
        }
        $comment = $handler->createModel($instanceId)->newQuery()->where('id', $comment->id)->first();
        return ['comment_srl' => Store::num($comment->id), 'vote' => Boards::commentVote($comment, $voteConfig)];
    }

    // ---- 추천·스크랩·신고

    /** 글 아래 기능 상태 (document 응답의 actions) */
    public static function actions(Board $doc, $item, $config)
    {
        $user = Auth::user();
        $handler = app('xe.board.handler');
        $loggedIn = Auth::check();
        $mine = $loggedIn && $doc->user_id === $user->getId();
        $myVote = 0;
        if ($loggedIn) {
            $myVote = $handler->hasVote($doc, $user, 'assent') ? 1 : ($handler->hasVote($doc, $user, 'dissent') ? -1 : 0);
        }
        return [
            // XE3 웹은 추천 수를 누르면 추천한 사람 목록을 늘 보여 준다 (숨기는 설정이 없다)
            'vote_up' => ['enabled' => $config->get('assent') === true, 'count' => (int)$doc->assent_count, 'public' => $config->get('assent') === true],
            'vote_down' => ['enabled' => $config->get('dissent') === true, 'count' => (int)$doc->dissent_count, 'public' => $config->get('dissent') === true],
            'my_vote' => $myVote,
            // XE3 는 같은 추천을 한 번 더 누르면 취소된다
            'can_cancel_vote' => true,
            'is_mine' => $mine,
            'can_scrap' => $loggedIn,
            'can_declare' => $loggedIn && !$mine && app('xe.plugin')->getPlugin('claim') !== null,
            // 이미 내 스크랩(=즐겨찾기)에 있는지 (0.3.0~)
            'scrapped' => $loggedIn && $handler->hasFavorite($doc->id, $user->getId()),
        ];
    }

    private static function readableDocument()
    {
        list($item, $config) = self::board();
        $doc = self::document($item);
        // 글 화면(document)과 같은 판단: 엔진 getItem 이 통과해야 한다(비밀글·휴지통·미승인 글을 거른다), 읽기 권한·상담 게시판(자기 글만)
        $doc = Boards::readableDocument($item, $config, Store::num($doc->id));
        return [$item, $config, $doc];
    }

    /** 추천(point 1)·비추천(-1). cancel 이면 취소. 웹 vote() 와 같은 핸들러 */
    public static function vote()
    {
        list($item, $config, $doc) = self::readableDocument();
        $option = (int)Api::param('point', 1) < 0 ? 'dissent' : 'assent';
        if ($config->get($option) !== true) {
            throw new ApiError(403, 'not_permitted', $option === 'assent' ? Text::t('이 게시판은 추천을 쓰지 않습니다.') : Text::t('이 게시판은 비추천을 쓰지 않습니다.'));
        }
        if ($doc->user_id === Auth::id()) {
            throw new ApiError(403, 'not_permitted', '자기 글은 추천할 수 없습니다.');
        }
        $handler = app('xe.board.handler');
        $has = $handler->hasVote($doc, Auth::user(), $option);
        $cancel = (bool)Api::param('cancel');
        if ($has === $cancel) {
            $handler->vote($doc, Auth::user(), $option); // 있으면 취소, 없으면 추천 (웹과 같은 동작)
            if (!$has) {
                $doc->refresh();
                Points::voted($doc, $option); // 추천받은 글쓴이 포인트 (웹과 같게)
            }
        } elseif (!$cancel) {
            throw new ApiError(400, 'already_voted', $option === 'assent' ? Text::t('이미 추천했습니다.') : Text::t('이미 비추천했습니다.'));
        }
        $doc->refresh();
        return self::actions($doc, $item, $config);
    }

    /** 추천한 사람: 웹(BoardModuleController::votedUsers)과 같은 기록(추천 카운터 로그) */
    public static function voters()
    {
        list(, $config, $doc) = self::readableDocument();
        $option = (int)Api::param('point', 1) < 0 ? 'dissent' : 'assent';
        if ($config->get($option) !== true) {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        $counter = app('xe.board.handler')->getVoteCounter();
        $logs = $counter->newModel()->where('counter_name', $counter->getName())->where('target_id', $doc->id)
            ->where('counter_option', $option)->orderBy('created_at', 'desc')->take(500)->get();
        $voters = [];
        foreach ($logs as $log) {
            $user = $log->user_id ? \Xpressengine\User\Models\User::find($log->user_id) : null;
            if ($user) {
                $voters[] = ['nick_name' => (string)$user->getDisplayName(), 'profile_image' => Api::profileImage($user)];
            }
        }
        return ['voters' => $voters];
    }

    /** 스크랩 = XE3 게시판 즐겨찾기 */
    public static function scrap()
    {
        list(, , $doc) = self::readableDocument();
        $handler = app('xe.board.handler');
        if ($handler->hasFavorite($doc->id, Auth::id()) === false) {
            $handler->addFavorite($doc->id, Auth::id());
        }
        return ['scrapped' => true];
    }

    /** 신고 = claim 플러그인 (웹 글 메뉴의 신고와 같은 기록) */
    public static function report()
    {
        list(, , $doc) = self::readableDocument();
        $claim = app('xe.claim.handler');
        $claim->set('module/board@board');
        try {
            $claim->add($doc->id, Auth::user(), (string)app('xe.board.url')->getShow($doc));
        } catch (\Exception $e) {
            throw new ApiError(400, 'already_declared', '이미 신고한 글입니다.');
        }
        return ['declared' => true];
    }
}
