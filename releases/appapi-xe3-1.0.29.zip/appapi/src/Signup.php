<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Xpressengine\User\Models\User;

/**
 * 회원가입 (1.0.28~). 웹 가입(RegisterController::postRegister)과 같은 설정·같은 엔진 동작:
 * 관리 화면에서 켠 가입 양식 조각(user.register.forms: 기본 정보·약관·캡챠·추가 항목)마다 그 조각의 validate() 를 부르고,
 * 저장은 회원 처리기(xe.user create, 기본 가입 그룹·약관 동의 기록), 메일 인증을 쓰면 웹과 같은 인증 메일을 보낸다.
 * 앱이 풀 수 없는 캡챠(구글 reCAPTCHA v2 밖)나 앱이 그릴 수 없는 필수 추가 항목이 있으면 웹으로 안내(web_only).
 */
class Signup
{
    /** 앱 가입을 처리하는 중 (사이트의 다른 가입 조각이 웹 화면 전용 확인을 건너뛸 때 본다) */
    public static $running = false;

    /** 관리 화면에서 켠 가입 양식 조각 (웹 postRegister 와 같은 고르기) */
    private static function parts()
    {
        $config = app('xe.config')->get('user.register');
        $parts = app('xe.user')->getRegisterParts();
        $activated = array_keys(array_intersect_key(array_flip($config->get('forms', [])), $parts));
        return collect($parts)->filter(function ($part, $key) use ($activated) {
            return in_array($key, $activated) || $part::isImplicit();
        });
    }

    private static function joinable()
    {
        return app('xe.config')->getVal('user.register.joinable') === true;
    }

    private static function captchaUsed()
    {
        return self::parts()->has('captcha') && app('xe.captcha')->available();
    }

    /** 앱이 그릴 수 없는 필수 추가 항목(동적 필드)이 있는가 */
    private static function requiredDynamicField()
    {
        if (!self::parts()->has('dynamic-fields')) {
            return false;
        }
        try {
            $part = new \Xpressengine\User\Parts\DynamicFieldPart(Api::$request);
            foreach ((array)$part->rules() as $rule) {
                if (strpos(is_array($rule) ? implode('|', $rule) : (string)$rule, 'required') !== false) {
                    return true;
                }
            }
        } catch (\Throwable $e) {
            report($e);
            return true;
        }
        return false;
    }

    /** 약관 (사이트가 쓰는 것, 웹 가입 화면의 약관 동의와 같다) */
    private static function terms()
    {
        $out = [];
        foreach (app('xe.terms')->fetchEnabled() as $i => $term) {
            $content = preg_replace('#<(br|/p|/h[1-6]|/li|/div|/tr)\b[^>]*>#i', "\n", (string)xe_trans($term->content));
            $content = html_entity_decode(strip_tags($content), ENT_QUOTES, 'UTF-8');
            $out[] = ['term' => $term, 'index' => count($out), 'title' => (string)xe_trans($term->title),
                'content' => trim(preg_replace("/\n{3,}/", "\n\n", preg_replace("/[ \t]+\n/", "\n", $content))), 'required' => $term->isRequire()];
        }
        return $out;
    }

    /** GET signup.form */
    public static function form()
    {
        $web = rtrim(url('/'), '/') . '/auth/register';
        if (!self::joinable()) {
            return ['enabled' => false, 'web_only' => true, 'web_url' => $web, 'basic' => [], 'agreements' => [], 'password_hint' => '', 'needs_confirm' => false, 'fields' => []];
        }
        $basic = [['name' => 'email_address', 'title' => (string)xe_trans('xe::email'), 'required' => true]];
        if (app('xe.user')->isUseLoginId() === true) {
            $basic[] = ['name' => 'user_id', 'title' => (string)xe_trans('xe::id'), 'required' => true];
        }
        if (app('xe.config')->getVal('user.register.use_display_name') === true) {
            $basic[] = ['name' => 'nick_name', 'title' => (string)xe_trans('xe::name'), 'required' => true];
        }
        $captcha = self::captchaUsed();
        $widget = $captcha ? Captcha::widget() : null;
        $agreements = [];
        foreach (self::terms() as $t) {
            $agreements[] = ['index' => $t['index'], 'title' => $t['title'], 'content' => $t['content'], 'required' => $t['required']];
        }
        return [
            'enabled' => true,
            // 캡챠를 쓰면 위젯을 아는 앱(captcha_solve)만 앱에서 푼다(예전 앱은 웹으로). 앱이 그릴 수 없는 필수 추가 항목이 있으면 웹에서만
            'web_only' => $captcha || self::requiredDynamicField(),
            'captcha' => $captcha && !self::requiredDynamicField(),
            'captcha_widget' => self::requiredDynamicField() ? null : $widget,
            'web_url' => $web,
            'basic' => $basic,
            'agreements' => $agreements,
            'password_hint' => '',
            'needs_confirm' => (string)app('xe.config')->getVal('user.register.register_process', User::STATUS_ACTIVATED) === User::STATUS_PENDING_EMAIL,
            'fields' => [],
        ];
    }

    /** POST signup {email_address, user_id?, nick_name?, password, agreements, captcha_response?, device_name, platform} */
    public static function signup()
    {
        if (!self::joinable()) {
            throw new ApiError(403, 'not_permitted', (string)xe_trans('xe::joinNotAllowed'));
        }
        if (self::requiredDynamicField()) {
            throw new ApiError(403, 'not_permitted', '웹사이트에서 가입해 주세요.');
        }
        // 약관: 필수 약관을 모두 동의해야 한다 (웹 약관 동의 화면·조각과 같은 판단). 동의한 약관을 기록한다
        $accepted = array_map('intval', Api::arrayParam('agreements'));
        $agreed = [];
        foreach (self::terms() as $t) {
            if (in_array($t['index'], $accepted, true)) {
                $agreed[] = $t['term']->id;
            } elseif ($t['required']) {
                throw new ApiError(400, 'signup_failed', (string)xe_trans('xe::pleaseAcceptRequireTerms'));
            }
        }
        $input = [
            'email' => trim((string)Api::param('email_address', '')),
            'password' => (string)Api::param('password', ''),
        ];
        if (app('xe.user')->isUseLoginId() === true) {
            $input['login_id'] = trim((string)Api::param('user_id', ''));
        }
        if (app('xe.config')->getVal('user.register.use_display_name') === true) {
            $input['display_name'] = trim((string)Api::param('nick_name', ''));
        }
        if ($agreed) {
            $input['user_agree_terms'] = $agreed;
        }
        $request = Api::$request;
        $request->merge($input);
        if (self::captchaUsed()) {
            if (!Captcha::applyResponse()) {
                throw Captcha::error('자동 입력 방지 확인이 필요합니다.');
            }
        }
        // 웹 postRegister 와 같이 켠 조각마다 검사 (아이디·메일·이름 형식과 중복, 비밀번호 규칙, 캡챠 확인)
        self::$running = true;
        try {
            foreach (self::parts() as $key => $class) {
                if ($key === 'agreements') {
                    continue; // 약관은 위에서 (앱은 동의한 약관 번호를 보낸다)
                }
                (new $class($request))->validate();
            }
        } catch (ValidationException $e) {
            $errors = $e->validator->errors();
            if ($errors->has('CaptchaParts')) {
                throw Captcha::error((string)$errors->first('CaptchaParts'));
            }
            throw new ApiError(400, 'signup_failed', (string)$errors->first(), [], true);
        } finally {
            self::$running = false;
        }
        $userData = $input;
        $joinGroup = app('xe.config')->get('user.register')->get('joinGroup');
        if ($joinGroup !== null) {
            $userData['group_id'] = [$joinGroup];
        }
        \XeDB::beginTransaction();
        try {
            $user = app('xe.user')->create($userData);
        } catch (ValidationException $e) {
            // 회원 처리기의 확인(이미 쓰는 메일·아이디·이름 등)
            \XeDB::rollback();
            throw new ApiError(400, 'signup_failed', (string)$e->validator->errors()->first(), [], true);
        } catch (\Xpressengine\User\Exceptions\UserException $e) {
            \XeDB::rollback();
            throw new ApiError(400, 'signup_failed', (string)$e->getMessage(), [], true);
        } catch (\Throwable $e) {
            \XeDB::rollback();
            throw $e;
        }
        \XeDB::commit();
        if ($user->status === User::STATUS_PENDING_EMAIL) {
            // 웹과 같은 인증 메일 (RegisterController::sendApproveEmail)
            $mail = app('xe.user')->createEmail($user, ['address' => $user->email], false);
            $token = app('xe.user.register.tokens')->create('register', ['email' => $user->email, 'user_id' => $user->id]);
            app('xe.auth.email')->sendEmailForRegisterApprove($mail, $token);
            return ['needs_confirm' => true];
        }
        if ($user->status !== User::STATUS_ACTIVATED) {
            return ['needs_confirm' => false, 'logged_in' => false]; // 관리자 승인 뒤
        }
        $tokens = Store::issue($user->getId(), $user->password, Api::param('device_name', ''), Api::param('platform', ''), Api::$request->ip());
        Auth::setUser($user);
        return ['needs_confirm' => false, 'logged_in' => true, 'tokens' => $tokens, 'member' => Api::profile()];
    }
}
