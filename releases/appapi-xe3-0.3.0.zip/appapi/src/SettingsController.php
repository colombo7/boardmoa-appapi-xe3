<?php
namespace Xpressengine\Plugins\Appapi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

/** 관리 화면: 사이트 → 설정 → 플러그인 → 게시판모아 앱 연동 → 설정 (버전·업데이트·연결 주소) */
class SettingsController extends Controller
{
    public function index(Request $request)
    {
        return app('xe.presenter')->make(Plugin::view('views.settings'), [
            'check' => $request->has('check') ? Updater::check() : null,
            'current' => Updater::currentVersion(),
            'apiUrl' => rtrim(url('/'), '/') . '/modules/appapi/api.php?r=site',
            'result' => session('appapi_update'),
        ]);
    }

    public function update()
    {
        $result = Updater::update();
        return redirect()->route('appapi::settings')->with('appapi_update', $result);
    }
}
