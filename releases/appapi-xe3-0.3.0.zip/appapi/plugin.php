<?php
/**
 * 게시판모아(BoardMoa) 앱 연동 — XE3 플러그인.
 *
 * XE1·Rhymix 모듈(server/appapi)과 같은 주소·규약(docs/API.md)으로 응답해서, 앱은 엔진을 구별하지 않는다.
 *   /modules/appapi/api.php?r=<route>  ·  /appapi/index.php?r=<route>
 * 권한 판단은 XE3 엔진(Gate, 게시판 권한)에 맡긴다.
 */

namespace Xpressengine\Plugins\Appapi;

use Route;
use Xpressengine\Plugin\AbstractPlugin;

class Plugin extends AbstractPlugin
{
    public function boot()
    {
        // 세션·CSRF 없이 (앱은 쿠키를 쓰지 않고 Bearer 토큰으로 인증한다)
        foreach (['modules/appapi/api.php', 'appapi/index.php'] as $path) {
            Route::any($path, '\\' . Api::class . '@handle');
        }
        // 관리 화면 (설정 → 플러그인 목록의 '설정'): 버전·업데이트 확인
        Route::settings(static::getId(), function () {
            Route::get('/', ['as' => 'appapi::settings', 'uses' => 'SettingsController@index']);
            Route::post('update', ['as' => 'appapi::settings.update', 'uses' => 'SettingsController@update']);
        }, ['namespace' => __NAMESPACE__]);
    }

    public function getSettingsURI()
    {
        return route('appapi::settings');
    }

    public function activate($installedVersion = null)
    {
        Store::ensureTables();
    }

    public function install()
    {
        Store::ensureTables();
    }

    public function update()
    {
        Store::ensureTables();
    }

    public function checkUpdated()
    {
        return Store::tablesExist();
    }
}
