@section('page_title')
    <h2>게시판모아 앱 연동</h2>
@endsection

@section('page_description')
    <small>스마트폰 앱 게시판모아(BoardMoa)가 이 사이트의 게시판을 쓸 수 있게 하는 플러그인입니다. (XE3용 시험판)</small>
@stop

<div class="row">
    <div class="col-sm-12">
        <div class="panel-group">
            <div class="panel">
                <div class="panel-heading">
                    <div class="pull-left"><h3 class="panel-title">버전과 업데이트</h3></div>
                </div>
                <div class="panel-body">
                    @if ($result)
                        <div class="alert {{ $result['ok'] ? 'alert-success' : 'alert-danger' }}">
                            {{ $result['message'] }}
                            @if (!empty($result['backup']))<br><small>이전 파일 백업: {{ $result['backup'] }}</small>@endif
                        </div>
                    @endif

                    <p>설치된 버전: <strong>{{ $current }}</strong></p>

                    @if ($check)
                        @if ($check['error'])
                            <div class="alert alert-warning">{{ $check['error'] }}</div>
                        @elseif ($check['has_update'])
                            <p>새 버전: <strong>{{ $check['latest'] }}</strong> ({{ $check['date'] }})</p>
                            @if ($check['notes'])<p style="white-space:pre-line">{{ $check['notes'] }}</p>@endif
                            @if (!$check['zip_available'])
                                <div class="alert alert-warning">서버 PHP 에 zip 확장(ZipArchive)이 없어 자동 업데이트를 할 수 없습니다. 공개 저장소에서 받아 plugins/appapi 를 바꿔 주세요.</div>
                            @elseif (!$check['writable'])
                                <div class="alert alert-warning">웹 서버가 플러그인 폴더에 쓸 수 없습니다: {{ implode(', ', array_slice($check['problems'], 0, 3)) }}</div>
                            @else
                                <form method="post" action="{{ route('appapi::settings.update') }}" onsubmit="this.querySelector('button').disabled=true">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <button type="submit" class="xe-btn xe-btn-primary">{{ $check['latest'] }}(으)로 업데이트</button>
                                    <small class="text-muted">전자서명을 확인하고, 지금 파일을 백업한 뒤 바꿉니다.</small>
                                </form>
                            @endif
                        @elseif ($check['is_newer'])
                            <p class="text-muted">공개된 최신판({{ $check['latest'] }})보다 새 버전이 설치돼 있습니다.</p>
                        @else
                            <p class="text-success">최신 버전입니다.</p>
                        @endif
                    @else
                        <a href="{{ route('appapi::settings', ['check' => 1]) }}" class="xe-btn xe-btn-default">업데이트 확인</a>
                    @endif

                    <hr>
                    <h4>설치 현황 — 개발자에게 알리기</h4>
                    <form method="post" action="{{ route('appapi::settings.share') }}">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="share_site" value="N">
                        <label><input type="checkbox" name="share_site" value="Y" {{ $shareSite ? 'checked' : '' }} onchange="this.form.submit()"> 업데이트를 확인할 때 이 사이트 주소를 알립니다</label>
                        <p class="text-muted"><small>업데이트를 확인하면 이 사이트 주소·이름·엔진·플러그인 버전을 게시판모아 개발자(EasyAppLabs)에게 알립니다. 회원이나 글 정보는 보내지 않으며 공개하지 않습니다. 플러그인이 어떤 엔진과 버전에서 쓰이는지 알 수 있어, 여러 버전에서 잘 동작하도록 호환성을 맞추고 새 기능을 개발하는 데 참고 자료가 됩니다.</small></p>
                    </form>

                    <hr>
                    <p class="text-muted">
                        앱 연결 주소: <a href="{{ $apiUrl }}" target="_blank">{{ $apiUrl }}</a><br>
                        배포·설치 안내: <a href="https://github.com/colombo7/boardmoa-appapi-xe3" target="_blank">github.com/colombo7/boardmoa-appapi-xe3</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
