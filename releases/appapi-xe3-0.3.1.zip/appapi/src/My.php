<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Support\Facades\Auth;
use XeDB;
use XeMenu;
use Xpressengine\Document\Models\Document;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Board\Models\BoardFavorite;
use Xpressengine\Plugins\Comment\Models\Comment;
use Xpressengine\User\Models\User;

/**
 * 내 활동·내 정보 (로그인 필요).
 * XE3 에 있는 것만 메뉴로 보낸다: 내가 쓴 글·댓글, 스크랩(=게시판 즐겨찾기). 쪽지·친구·임시 저장은 XE3 에 없어 보내지 않는다.
 * 글은 지금도 목록 권한이 있는 게시판의 것만 (권한이 바뀐 게시판의 글이 새지 않게).
 */
class My
{
    const PER_PAGE = 20;

    public static function menu()
    {
        return ['items' => [
            ['key' => 'documents', 'title' => '내가 쓴 글'],
            ['key' => 'comments', 'title' => '내가 쓴 댓글'],
            ['key' => 'scraps', 'title' => '스크랩'],
        ]];
    }

    /** 목록을 볼 수 있는 게시판 [instance_id => 메뉴 항목] */
    private static function boards()
    {
        $out = [];
        foreach (XeMenu::items()->query()->where('type', Boards::BOARD)->get() as $item) {
            if (Boards::grant($item->id)['list']) {
                $out[$item->id] = $item;
            }
        }
        return $out;
    }

    private static function page()
    {
        return max(1, Api::intParam('page', 1));
    }

    private static function paging($paginate)
    {
        return ['page' => (int)$paginate->currentPage(), 'total_pages' => max(1, (int)$paginate->lastPage()), 'total_count' => (int)$paginate->total()];
    }

    public static function documents()
    {
        $boards = self::boards();
        $paginate = Board::whereIn('instance_id', array_keys($boards) ?: [''])
            ->where('user_id', Auth::id())
            ->where('status', '!=', Document::STATUS_TRASH)
            ->where('display', '!=', Document::DISPLAY_HIDDEN)
            ->orderBy('created_at', 'desc')
            ->paginate(self::PER_PAGE, ['*'], 'page', self::page());
        $documents = [];
        foreach ($paginate as $doc) {
            $item = $boards[$doc->instance_id];
            $summary = Boards::summary($doc, app('xe.board.config')->get($doc->instance_id), true);
            $summary['mid'] = (string)$item->url;
            $summary['board_title'] = Boards::title($item);
            $documents[] = $summary;
        }
        return ['documents' => $documents] + self::paging($paginate);
    }

    public static function comments()
    {
        $boards = self::boards();
        $handler = app('xe.plugin.comment')->getHandler();
        $map = [];
        foreach ($boards as $id => $item) {
            if ($commentInstance = $handler->getInstanceId($id)) {
                $map[$commentInstance] = $item;
            }
        }
        $paginate = Comment::whereIn('instance_id', array_keys($map) ?: [''])
            ->where('user_id', Auth::id())
            ->where('status', '!=', Document::STATUS_TRASH)
            ->where('display', '!=', Document::DISPLAY_HIDDEN)
            ->with('target')
            ->orderBy('created_at', 'desc')
            ->paginate(self::PER_PAGE, ['*'], 'page', self::page());
        $comments = [];
        foreach ($paginate as $c) {
            $doc = $c->target ? Board::find($c->target->target_id) : null;
            $item = $map[$c->instance_id];
            $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string)$c->content), ENT_QUOTES, 'UTF-8')));
            $comments[] = [
                'comment_srl' => Store::num($c->id),
                'document_srl' => $doc ? Store::num($doc->id) : 0,
                'content' => mb_substr($text, 0, 200),
                'regdate' => $c->created_at ? $c->created_at->toIso8601String() : null,
                'is_secret' => (int)$c->display === Document::DISPLAY_SECRET,
                'document_title' => $doc ? (string)$doc->title : '',
                'mid' => (string)$item->url,
                'board_title' => Boards::title($item),
            ];
        }
        return ['comments' => $comments] + self::paging($paginate);
    }

    /** 스크랩 = 게시판 즐겨찾기. 지금 볼 수 없는 게시판의 글은 제목을 감춘다(exists:false) */
    public static function scraps()
    {
        $boards = self::boards();
        $paginate = BoardFavorite::where('user_id', Auth::id())->orderBy('favorite_id', 'desc')
            ->paginate(self::PER_PAGE, ['*'], 'page', self::page());
        $documents = [];
        foreach ($paginate as $fav) {
            $doc = Board::find($fav->target_id);
            $item = $doc ? ($boards[$doc->instance_id] ?? null) : null;
            $visible = $doc && $item && (int)$doc->status !== Document::STATUS_TRASH;
            $documents[] = [
                'document_srl' => Store::num($fav->target_id),
                'title' => $visible ? (string)$doc->title : '',
                'author' => $visible ? (string)$doc->writer : '',
                'scrapped_at' => null,
                'mid' => $item ? (string)$item->url : null,
                'board_title' => $item ? Boards::title($item) : null,
                'exists' => $visible,
            ];
        }
        return ['documents' => $documents, 'folders' => [], 'folder_srl' => 0] + self::paging($paginate);
    }

    public static function deleteScrap()
    {
        $uuid = Store::uuid(Api::intParam('document_srl'));
        if ($uuid) {
            app('xe.board.handler')->removeFavorite($uuid, Auth::id());
        }
        return ['deleted' => true];
    }

    // ---- 내 정보

    public static function form()
    {
        $user = Auth::user();
        return [
            'nick_name' => (string)$user->getDisplayName(),
            'email_address' => (string)$user->email,
            'profile_image' => Api::profileImage($user),
            'can_change_nickname' => true,
            // XE3 는 이메일을 바꾸면 인증 절차가 따로 있어 웹에서 한다
            'can_change_email' => false,
            'profile_image_enabled' => false,
            'fields' => [],
        ];
    }

    private static function checkPassword($password)
    {
        $user = Auth::user();
        if (!Auth::getProvider()->validateCredentials($user, ['password' => (string)$password])) {
            throw new ApiError(400, 'invalid_password', '지금 비밀번호가 맞지 않습니다.');
        }
    }

    /** 닉네임 바꾸기: 웹(UserController::updateDisplayName)과 같은 검사(중복·형식) 뒤 같은 핸들러로 */
    public static function update()
    {
        self::checkPassword(Api::param('current_password'));
        $user = Auth::user();
        $name = Api::param('nick_name');
        if ($name !== null) {
            $name = str_replace('  ', ' ', trim((string)$name));
            if ($name !== $user->getDisplayName()) {
                $handler = app('xe.user');
                try {
                    $handler->validateDisplayName($name, $user);
                } catch (\Exception $e) {
                    throw new ApiError(400, 'update_failed', $e->getMessage() ?: '쓸 수 없는 닉네임입니다.');
                }
                XeDB::beginTransaction();
                try {
                    $handler->update($user, ['display_name' => $name]);
                    XeDB::commit();
                } catch (\Exception $e) {
                    XeDB::rollback();
                    throw new ApiError(400, 'update_failed', $e->getMessage() ?: '바꾸지 못했습니다.');
                }
            }
        }
        Auth::setUser(User::find($user->getId()));
        return Api::profile();
    }

    /** 비밀번호 바꾸기: 웹과 같은 규칙(xe_password) — 바뀌면 다른 기기 토큰은 무효, 이 기기에는 새 토큰 */
    public static function password()
    {
        self::checkPassword(Api::param('current_password'));
        $new = (string)Api::param('new_password', '');
        $validator = validator(['password' => $new, 'password_confirmation' => $new], ['password' => 'required|confirmed|xe_password']);
        if ($validator->fails()) {
            throw new ApiError(400, 'invalid_password', $validator->errors()->first('password'));
        }
        $user = Auth::user();
        XeDB::beginTransaction();
        try {
            app('xe.user')->update($user, ['password' => $new]);
            XeDB::commit();
        } catch (\Exception $e) {
            XeDB::rollback();
            throw new ApiError(400, 'invalid_password', $e->getMessage() ?: '바꾸지 못했습니다.');
        }
        $user = User::find($user->getId());
        Store::revokeUser($user->getId());
        $tokens = Store::issue($user->getId(), $user->password, Api::$token->device_name ?? '', Api::$token->platform ?? '', Api::$request->ip());
        return ['tokens' => $tokens];
    }

    /** 이름 메뉴: XE3 에는 쪽지·친구가 없어 '작성 글 보기'만 (그 회원의 글을 게시판에서 찾기) */
    public static function memberMenu()
    {
        $memberSrl = Api::intParam('member_srl');
        $uuid = Store::uuid($memberSrl);
        $user = $uuid ? User::find($uuid) : null;
        $actions = [];
        if ($user && Api::param('mid')) {
            $actions[] = ['type' => 'documents', 'label' => '작성 글 보기', 'mid' => (string)Api::param('mid'),
                'search' => ['search_target' => 'nick_name', 'search_keyword' => (string)$user->getDisplayName()]];
        }
        return ['member_srl' => $memberSrl, 'actions' => $actions];
    }

    /** 회원가입은 XE3 웹에서 (약관·가입 항목·메일 인증 절차가 사이트마다 달라서) */
    public static function signupForm()
    {
        return ['enabled' => false, 'web_only' => true, 'web_url' => rtrim(url('/'), '/') . '/auth/register', 'basic' => [], 'agreements' => [],
            'password_hint' => '', 'needs_confirm' => false, 'fields' => []];
    }
}
