<?php
namespace Xpressengine\Plugins\Appapi;

/**
 * 플러그인 스스로 업데이트 (관리 화면의 [업데이트 확인] → [업데이트]). XE1·Rhymix 모듈(appapi.updater.php)과 같은 방식.
 * 공개 저장소(github.com/colombo7/boardmoa-appapi-xe3)의 latest.json 을 읽고, zip 을 받아 SHA-256·전자서명(conf/release-public.pem)을
 * 확인한 뒤 지금 폴더를 storage/app/appapi_backup/ 에 백업하고 덮어쓴다. XE3 코어·스토어는 쓰지 않는다.
 */
class Updater
{
    const MANIFEST_URL = 'https://raw.githubusercontent.com/colombo7/boardmoa-appapi-xe3/main/latest.json';
    const RELEASE_BASE = 'https://raw.githubusercontent.com/colombo7/boardmoa-appapi-xe3/main/';

    /** plugins/appapi/ */
    public static function pluginDir()
    {
        return rtrim(str_replace('\\', '/', dirname(__DIR__)), '/') . '/';
    }

    /** 파일에 적힌 버전 (실행 중인 클래스 상수가 아니라 디스크의 것: 업데이트 직후에도 맞게) */
    public static function currentVersion()
    {
        $text = (string)@file_get_contents(self::pluginDir() . 'src/Api.php');
        return preg_match("/const VERSION = '([0-9.]+)'/", $text, $m) ? $m[1] : Api::VERSION;
    }

    /** 설치 현황: 이 사이트 주소를 게시판모아 개발자 서버에 알린다 (설정 화면에서 끌 수 있다). 실패해도 조용히 넘어간다. XE1 모듈과 같은 곳 */
    const REGISTRY_URL = 'https://easyapplabs.com/boardmoa/registry.php';

    /** 개발자에게 알리기 (기본 켬) */
    public static function shareSite()
    {
        $config = app('xe.config')->get('appapi');
        return !($config && $config->get('share_site') === 'N');
    }

    public static function report()
    {
        if (!self::shareSite() || !function_exists('curl_init')) {
            return;
        }
        $ch = curl_init(self::REGISTRY_URL);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS => json_encode(['url' => rtrim(url('/'), '/') . '/', 'connector' => 'appapi-xe3']),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 20,
            CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4, CURLOPT_USERAGENT => 'BoardMoa-appapi-xe3']);
        @curl_exec($ch);
        curl_close($ch);
    }

    public static function check()
    {
        self::report();
        $problems = self::unwritablePaths();
        $result = [
            'current' => self::currentVersion(),
            'latest' => null, 'notes' => '', 'date' => '',
            'has_update' => false, 'is_newer' => false,
            'writable' => !$problems, 'problems' => $problems,
            'zip_available' => class_exists('ZipArchive'),
            'error' => null,
        ];
        $manifest = self::manifest();
        if (!is_array($manifest)) {
            $result['error'] = $manifest;
            return $result;
        }
        $result['latest'] = $manifest['version'];
        $result['notes'] = (string)($manifest['notes'] ?? '');
        $result['date'] = (string)($manifest['date'] ?? '');
        $result['has_update'] = version_compare($manifest['version'], $result['current'], '>');
        $result['is_newer'] = version_compare($result['current'], $manifest['version'], '>');
        return $result;
    }

    public static function update()
    {
        $from = self::currentVersion();
        $fail = function ($message) use ($from) {
            return ['ok' => false, 'message' => $message, 'from' => $from, 'to' => null, 'backup' => null];
        };
        if (!class_exists('ZipArchive')) {
            return $fail('서버 PHP 에 zip 확장(ZipArchive)이 없어 자동 업데이트를 할 수 없습니다. 압축을 풀어 직접 올려 주세요.');
        }
        if ($problems = self::unwritablePaths()) {
            return $fail('웹 서버가 플러그인 폴더에 쓸 수 없습니다: ' . implode(', ', array_slice($problems, 0, 3)));
        }
        $manifest = self::manifest();
        if (!is_array($manifest)) {
            return $fail($manifest);
        }
        if (!version_compare($manifest['version'], $from, '>')) {
            return ['ok' => true, 'message' => '이미 최신 버전입니다.', 'from' => $from, 'to' => $from, 'backup' => null];
        }
        $zipData = self::fetch(self::RELEASE_BASE . $manifest['zip']);
        if ($zipData === false || $zipData === '') {
            return $fail('업데이트 파일을 받지 못했습니다.');
        }
        if (!hash_equals(strtolower($manifest['sha256']), hash('sha256', $zipData))) {
            return $fail('받은 파일이 손상되었습니다(SHA-256 불일치).');
        }
        if (!self::verifySignature($zipData, $manifest['signature'])) {
            return $fail('전자서명이 맞지 않아 업데이트하지 않았습니다.');
        }

        $tmp = rtrim(sys_get_temp_dir(), '/') . '/appapi-xe3-update-' . bin2hex(random_bytes(6));
        @mkdir($tmp, 0700, true);
        $zipFile = $tmp . '/package.zip';
        file_put_contents($zipFile, $zipData);
        $zip = new \ZipArchive();
        if ($zip->open($zipFile) !== true) {
            self::removeDir($tmp);
            return $fail('업데이트 파일을 열 수 없습니다.');
        }
        // 묶음 안의 경로는 모두 appapi/ 아래여야 한다 (../ 등 금지)
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (strpos($name, 'appapi/') !== 0 || strpos($name, '..') !== false || strpos($name, "\0") !== false) {
                $zip->close();
                self::removeDir($tmp);
                return $fail('업데이트 파일 구성이 올바르지 않습니다.');
            }
        }
        $zip->extractTo($tmp . '/x');
        $zip->close();
        $source = $tmp . '/x/appapi/';
        $newApi = (string)@file_get_contents($source . 'src/Api.php');
        if (!is_file($source . 'plugin.php') || strpos($newApi, "const VERSION = '" . $manifest['version'] . "'") === false) {
            self::removeDir($tmp);
            return $fail('업데이트 파일의 버전이 맞지 않습니다.');
        }

        $backup = self::backupDir($from);
        if ($backup === null || !self::copyDir(self::pluginDir(), $backup)) {
            self::removeDir($tmp);
            return $fail('백업을 만들지 못해 업데이트하지 않았습니다.');
        }
        if (!self::copyDir($source, self::pluginDir())) {
            self::copyDir($backup, self::pluginDir());
            self::removeDir($tmp);
            return $fail('파일을 쓰다가 실패해 이전 버전으로 되돌렸습니다.');
        }
        self::removeDir($tmp);
        self::resetOpcache(self::pluginDir());
        return ['ok' => true, 'message' => $from . ' → ' . $manifest['version'] . ' 업데이트를 마쳤습니다.', 'from' => $from, 'to' => $manifest['version'], 'backup' => $backup];
    }

    /** latest.json 을 읽어 검사한 배열, 실패하면 까닭 문자열 */
    private static function manifest()
    {
        $text = self::fetch(self::MANIFEST_URL . '?t=' . time());
        if ($text === false || $text === '') {
            return '업데이트 정보를 받지 못했습니다. 서버에서 github 로 나가는 연결을 확인해 주세요.';
        }
        $manifest = json_decode($text, true);
        if (!is_array($manifest) || empty($manifest['version']) || empty($manifest['zip']) || empty($manifest['sha256']) || empty($manifest['signature'])
            || !preg_match('/^[0-9]+(\.[0-9]+){1,3}$/', $manifest['version']) || !preg_match('#^releases/appapi-xe3-[0-9.]+\.zip$#', $manifest['zip'])) {
            return '업데이트 정보 형식이 올바르지 않습니다.';
        }
        if (!empty($manifest['min_php']) && version_compare(PHP_VERSION, $manifest['min_php'], '<')) {
            return '새 버전은 PHP ' . $manifest['min_php'] . ' 이상이 필요합니다 (이 서버 ' . PHP_VERSION . ').';
        }
        return $manifest;
    }

    private static function verifySignature($data, $signatureBase64)
    {
        $public = @file_get_contents(self::pluginDir() . 'conf/release-public.pem');
        $signature = base64_decode((string)$signatureBase64, true);
        if (!$public || $signature === false || !function_exists('openssl_verify')) {
            return false;
        }
        return openssl_verify($data, $signature, $public, OPENSSL_ALGO_SHA256) === 1;
    }

    /** 일시적인 연결 실패가 있어 세 번까지 (IPv4 우선) */
    private static function fetch($url)
    {
        for ($try = 1; $try <= 3; $try++) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 60, CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4, CURLOPT_USERAGENT => 'BoardMoa-appapi-xe3']);
            $body = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($body !== false && $status === 200) {
                return $body;
            }
            if ($try < 3) {
                sleep(1);
            }
        }
        return false;
    }

    private static function unwritablePaths()
    {
        $base = self::pluginDir();
        $problems = is_writable($base) ? [] : ['plugins/appapi/'];
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($base, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $path => $info) {
            if (!is_writable($path)) {
                $problems[] = 'plugins/appapi/' . substr(str_replace('\\', '/', $path), strlen($base));
            }
        }
        return $problems;
    }

    private static function backupDir($version)
    {
        $dir = storage_path('app/appapi_backup/' . preg_replace('/[^0-9.]/', '', $version) . '-' . date('YmdHis')) . '/';
        return @mkdir($dir, 0755, true) ? $dir : null;
    }

    private static function copyDir($from, $to)
    {
        $from = rtrim($from, '/') . '/';
        $to = rtrim($to, '/') . '/';
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($from, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $path => $info) {
            $relative = substr(str_replace('\\', '/', $path), strlen($from));
            if (basename($relative) === '.DS_Store' || strpos(basename($relative), '._') === 0) {
                continue;
            }
            if ($info->isDir()) {
                if (!is_dir($to . $relative) && !@mkdir($to . $relative, 0755, true)) {
                    return false;
                }
            } elseif (!@copy($path, $to . $relative)) {
                return false;
            }
        }
        return true;
    }

    private static function removeDir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($iterator as $path => $info) {
            $info->isDir() ? @rmdir($path) : @unlink($path);
        }
        @rmdir($dir);
    }

    private static function resetOpcache($dir)
    {
        if (!function_exists('opcache_invalidate')) {
            return;
        }
        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $path => $info) {
            if (substr($path, -4) === '.php') {
                @opcache_invalidate($path, true);
            }
        }
    }
}
