<?php
namespace Xpressengine\Plugins\Appapi;

/** 앱에 돌려줄 오류 (HTTP 상태, 오류 코드, 사용자에게 보일 문장) */
class ApiError extends \Exception
{
    public $status;
    public $codeName;

    public function __construct($status, $code, $message)
    {
        parent::__construct($message);
        $this->status = $status;
        $this->codeName = $code;
    }
}
