<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use XeDB;
use XeEditor;
use XeMedia;
use XeStorage;
use Xpressengine\Editor\EditorHandler;
use Xpressengine\Permission\Instance;
use Xpressengine\Plugins\Board\BoardPermissionHandler;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Comment\Models\Comment;

/**
 * 쓰기: 글·댓글 쓰기·고치기·지우기, 추천·스크랩·신고.
 * 웹 화면(BoardModuleController·댓글 UserController)과 같은 판단(권한 Gate, 본인 확인, 비밀글·공지 설정)을 하고,
 * 실제 저장은 엔진의 서비스·핸들러(BoardService::store 등)에 맡긴다. 그래서 이벤트(알림·포인트 등)도 웹과 같다.
 */
class Write
{
    const MAX_PHOTOS = 30;

    /** 읽을 수 있는 게시판 [메뉴 항목, 설정]. 못 읽으면 없는 게시판처럼 */
    private static function board()
    {
        $item = \XeMenu::items()->query()->where('url', (string)Api::param('mid'))->first();
        $config = $item && $item->type === Boards::BOARD ? app('xe.board.config')->get($item->id) : null;
        if (!$config || !Boards::grant($item->id)['list']) {
            throw new ApiError(404, 'board_not_found', '없는 게시판입니다.');
        }
        return [$item, $config];
    }

    private static function perm($instanceId)
    {
        return new Instance(app(BoardPermissionHandler::class)->name($instanceId));
    }

    private static function denied()
    {
        return new ApiError(403, 'not_permitted', Api::message('not_permitted'));
    }

    /** 앱은 일반 글자로 보낸다: 태그는 글자로, 줄바꿈은 살린다 */
    private static function textToHtml($text)
    {
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string)$text));
        if ($text === '') {
            return '';
        }
        return '<p>' . nl2br(htmlspecialchars(mb_substr($text, 0, 50000), ENT_QUOTES, 'UTF-8')) . '</p>';
    }

    /** 앱 꾸밈 편집기의 HTML. 글자·사진이 없으면(빈 줄만) 빈 본문 */
    private static function editorHtml($html)
    {
        $html = trim((string)$html);
        if (trim(str_replace(['&nbsp;', "\xC2\xA0"], ' ', strip_tags($html, '<img><video><iframe>'))) === '') {
            return '';
        }
        return mb_substr($html, 0, 500000);
    }

    /** 웹처럼 HTML 정리 (관리자는 원문 그대로) */
    private static function purify($html, $manager)
    {
        if ($manager) {
            return $html;
        }
        $purifier = new \Xpressengine\Support\Purifier();
        $purifier->allowModule(\Xpressengine\Editor\PurifierModules\EditorContent::class);
        $purifier->allowModule(\Xpressengine\Support\PurifierModules\Html5::class);
        return $purifier->purify($html);
    }

    /** 이 게시판 글 하나 (UUID) */
    private static function document($item)
    {
        $uuid = Store::uuid(Api::intParam('document_srl'));
        $doc = $uuid ? Board::division($item->id)->find($uuid) : null;
        if (!$doc || $doc->instance_id !== $item->id) {
            throw new ApiError(404, 'document_not_found', '없는 글입니다.');
        }
        return $doc;
    }

    /** 작성자 본인이거나 관리 권한 (웹 hasItemPerm 과 같은 판단) */
    private static function editable(Board $doc, $item)
    {
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        if (!$service->hasItemPerm($doc, Auth::user(), app('xe.board.identify'), Boards::grant($item->id)['manager'])) {
            throw self::denied();
        }
    }

    // ---- 사진

    /** multipart photos[] — 정상 업로드인 JPEG 만 */
    private static function photos()
    {
        $files = Api::$request->file('photos');
        if ($files === null) {
            return [];
        }
        $files = is_array($files) ? array_values($files) : [$files];
        if (count($files) > self::MAX_PHOTOS) {
            throw new ApiError(400, 'too_many_photos', '사진은 한 번에 30장까지 올릴 수 있습니다.');
        }
        foreach ($files as $file) {
            if (!$file->isValid()) {
                throw new ApiError(400, 'upload_failed', '사진을 올리지 못했습니다.');
            }
        }
        return $files;
    }

    /** 웹 에디터의 파일 올리기(EditorController::fileUpload)와 같은 검사·저장. [본문에 붙일 HTML, 파일 id 들] */
    private static function uploadPhotos($instanceId, array $photos)
    {
        $editor = XeEditor::get($instanceId);
        $config = $editor->getConfig();
        if (!$config->get('uploadActive') || Gate::denies('upload', Boards::editorPerm($instanceId))) {
            throw new ApiError(403, 'not_permitted', '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        $width = (string)Api::param('photo_width', 'full');
        $style = $width === 'half' ? 'width:50%;height:auto;' : ($width === 'original' ? 'max-width:100%;height:auto;' : 'width:100%;height:auto;');
        $html = '';
        $ids = [];
        foreach ($photos as $index => $photo) {
            if ($config->get('fileMaxSize') * 1024 * 1024 < $photo->getSize() && !$editor->isPrivileged()) {
                throw new ApiError(413, 'file_too_large', Text::t('사진이 이 게시판의 파일 크기 한도({0}MB)를 넘습니다.', $config->get('fileMaxSize')));
            }
            Points::beforeUpload($instanceId); // 포인트 플러그인의 편집기 파일 올리기 판단 (웹과 같게)
            $file = XeStorage::upload($photo, EditorHandler::FILE_UPLOAD_PATH, 'photo' . ($index + 1) . '.jpg');
            Points::uploaded($instanceId);
            if (XeMedia::is($file)) {
                XeMedia::createThumbnails(XeMedia::make($file), EditorHandler::THUMBNAIL_TYPE);
            }
            $ids[] = $file->id;
            $url = htmlspecialchars(Boards::absolute($file->url()), ENT_QUOTES, 'UTF-8');
            $html .= '<p><img class="__xe_image" data-id="' . $file->id . '" xe-file-id="' . $file->id . '" src="' . $url . '" alt="photo' . ($index + 1) . '.jpg" style="' . $style . '" /></p>';
        }
        return [$html, $ids];
    }

    // ---- 글

    public static function insertDocument()
    {
        list($item, $config) = self::board();
        if (Gate::denies(BoardPermissionHandler::ACTION_CREATE, self::perm($item->id))) {
            throw self::denied();
        }
        $title = trim((string)Api::param('title', ''));
        // content_format=html: 앱 꾸밈 편집기의 HTML (아래 purify 로 웹처럼 정리). 없으면(예전 앱) 일반 글자
        $content = Api::param('content_format') === 'html' ? self::editorHtml(Api::param('content', '')) : self::textToHtml(Api::param('content', ''));
        $photos = self::photos();
        if ($title === '' || ($content === '' && !$photos)) {
            throw new ApiError(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $secret = (bool)Api::param('is_secret');
        if ($secret && $config->get('secretPost') !== true) {
            throw new ApiError(403, 'not_permitted', '이 게시판은 비밀글을 쓸 수 없습니다.');
        }
        $editor = XeEditor::get($item->id);
        $fileIds = [];
        if ($photos) {
            list($html, $fileIds) = self::uploadPhotos($item->id, $photos);
            $content .= $html;
        }
        $inputs = [
            'title' => htmlspecialchars(mb_substr($title, 0, 180), ENT_COMPAT | ENT_HTML401, 'UTF-8', false),
            'content' => self::purify($content, Boards::grant($item->id)['manager']),
            'display' => $secret ? Board::DISPLAY_SECRET : Board::DISPLAY_VISIBLE,
            'allow_comment' => 1,
            'use_alarm' => 1,
            'slug' => \Xpressengine\Plugins\Board\Models\BoardSlug::convert('', $title),
            $editor->getFileInputName() => $fileIds,
        ];
        if ($category = Api::intParam('category_srl')) {
            $inputs['category_item_id'] = $category;
        }
        $request = Request::create(Api::$request->url(), 'POST', $inputs);
        $request->setUserResolver(function () { return Auth::user(); });
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $doc = $service->store($request, Auth::user(), $config, app('xe.board.identify'));
        return ['document_srl' => Store::num($doc->id)];
    }

    /** 고칠 글의 원본 HTML (고칠 수 있는 사람에게만) */
    public static function documentSource()
    {
        list($item) = self::board();
        $doc = self::document($item);
        self::editable($doc, $item);
        return [
            'document_srl' => Store::num($doc->id),
            'title' => html_entity_decode((string)$doc->title, ENT_QUOTES, 'UTF-8'),
            'content' => (string)$doc->content,
            'base_url' => rtrim(url('/'), '/') . '/',
            // XE3 는 제목 굵게·색이 없다. 공지만 관리자가 바꾼다
            'manage' => Boards::grant($item->id)['manager']
                ? ['is_notice' => (int)$doc->status === Board::STATUS_NOTICE, 'title_bold' => false, 'title_color' => '']
                : null,
        ];
    }

    public static function updateDocument()
    {
        list($item, $config) = self::board();
        $doc = self::document($item);
        self::editable($doc, $item);
        $manager = Boards::grant($item->id)['manager'];
        $title = trim((string)Api::param('title', ''));
        $content = (string)Api::param('content', '');
        if ($title === '' || trim(strip_tags($content, '<img>')) === '') {
            throw new ApiError(400, 'missing_content', '제목과 내용을 입력해 주세요.');
        }
        $editor = XeEditor::get($item->id);
        // 엔진의 고치기는 보낸 값으로 덮으므로 원래 값(비밀글·공지·분류·댓글 허용·첨부)을 채워 보낸다
        $notice = $manager && Api::param('is_notice') !== null ? (bool)Api::param('is_notice') && Api::param('is_notice') !== 'N' : (int)$doc->status === Board::STATUS_NOTICE;
        $fileIds = $doc->files->pluck('id')->all();
        $inputs = [
            'id' => $doc->id,
            'title' => htmlspecialchars(mb_substr($title, 0, 180), ENT_COMPAT | ENT_HTML401, 'UTF-8', false),
            'content' => self::purify($content, $manager),
            'display' => (int)$doc->display === Board::DISPLAY_SECRET ? Board::DISPLAY_SECRET : Board::DISPLAY_VISIBLE,
            'status' => $notice ? Board::STATUS_NOTICE : Board::STATUS_PUBLIC,
            'allow_comment' => (int)($doc->boardData->allow_comment ?? 1),
            'use_alarm' => (int)($doc->boardData->use_alarm ?? 1),
            'slug' => $doc->boardSlug->slug ?? \Xpressengine\Plugins\Board\Models\BoardSlug::convert('', $title),
            'category_item_id' => $doc->boardCategory->item_id ?? null,
            $editor->getFileInputName() => $fileIds,
        ];
        $request = Request::create(Api::$request->url(), 'POST', array_filter($inputs, function ($v) { return $v !== null; }));
        $request->setUserResolver(function () { return Auth::user(); });
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $doc = $service->update($doc, $request, Auth::user(), $config, app('xe.board.identify'));
        return ['document_srl' => Store::num($doc->id)];
    }

    public static function deleteDocument()
    {
        list($item, $config) = self::board();
        $doc = self::document($item);
        self::editable($doc, $item);
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $service->destroy($doc, $config, app('xe.board.identify'));
        return ['deleted' => true];
    }

    // ---- 댓글

    private static function commentHandler()
    {
        return app('xe.plugin.comment')->getHandler();
    }

    public static function insertComment()
    {
        list($item, $config) = self::board();
        $doc = self::document($item);
        $grant = Boards::grant($item->id);
        if (!$grant['view'] && $doc->user_id !== Auth::id()) {
            throw self::denied();
        }
        $handler = self::commentHandler();
        $instanceId = $handler->getInstanceId($item->id);
        if (!$instanceId || $config->get('comment') !== true || (int)($doc->boardData->allow_comment ?? 1) !== 1
            || Gate::denies('create', new Instance($handler->getKeyForPerm($instanceId)))) {
            throw new ApiError(403, 'not_permitted', '댓글을 쓸 수 없습니다.');
        }
        $content = self::textToHtml(Api::param('content', ''));
        if ($content === '') {
            throw new ApiError(400, 'missing_content', '내용을 입력해 주세요.');
        }
        $inputs = [
            'instance_id' => $instanceId,
            'target_id' => $doc->id,
            'target_type' => Board::class,
            'target_author_id' => $doc->getAuthor()->getId(),
            'content' => self::purify($content, false),
            'format' => XeEditor::get($instanceId)->htmlable() ? Comment::FORMAT_HTML : Comment::FORMAT_NONE,
            'display' => Api::param('is_secret') ? Comment::DISPLAY_SECRET : Comment::DISPLAY_VISIBLE,
        ];
        if ($parent = Store::uuid(Api::intParam('parent_srl'))) {
            $parentComment = $handler->createModel($instanceId)->newQuery()->where('id', $parent)->first();
            if (!$parentComment || $parentComment->target->target_id !== $doc->id) {
                throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
            }
            $inputs['parent_id'] = $parent;
        }
        \Event::dispatch('xe.plugin.comment.create', [Request::create(Api::$request->url(), 'POST', $inputs)]);
        $comment = $handler->create($inputs, Auth::user());
        return ['comment_srl' => Store::num($comment->id), 'document_srl' => Store::num($doc->id)];
    }

    public static function deleteComment()
    {
        list($item) = self::board();
        $handler = self::commentHandler();
        $instanceId = $handler->getInstanceId($item->id);
        $uuid = Store::uuid(Api::intParam('comment_srl'));
        $comment = ($instanceId && $uuid) ? $handler->createModel($instanceId)->newQuery()->where('instance_id', $instanceId)->where('id', $uuid)->first() : null;
        if (!$comment) {
            throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
        }
        // 웹과 같은 판단: 댓글 정책(CommentPolicy) 의 delete
        if (Gate::denies('delete', $comment)) {
            throw self::denied();
        }
        $trashed = $handler->trash($comment);
        if ($trashed && (int)$trashed->display !== Comment::DISPLAY_VISIBLE && $comment->getAuthor()->getId() === Auth::id()) {
            $handler->remove($trashed);
        }
        return ['deleted' => true];
    }

    // ---- 추천·스크랩·신고

    /** 글 아래 기능 상태 (document 응답의 actions) */
    public static function actions(Board $doc, $item, $config)
    {
        $user = Auth::user();
        $handler = app('xe.board.handler');
        $loggedIn = Auth::check();
        $mine = $loggedIn && $doc->user_id === $user->getId();
        $myVote = 0;
        if ($loggedIn) {
            $myVote = $handler->hasVote($doc, $user, 'assent') ? 1 : ($handler->hasVote($doc, $user, 'dissent') ? -1 : 0);
        }
        return [
            // XE3 웹은 추천 수를 누르면 추천한 사람 목록을 늘 보여 준다 (숨기는 설정이 없다)
            'vote_up' => ['enabled' => $config->get('assent') === true, 'count' => (int)$doc->assent_count, 'public' => $config->get('assent') === true],
            'vote_down' => ['enabled' => $config->get('dissent') === true, 'count' => (int)$doc->dissent_count, 'public' => $config->get('dissent') === true],
            'my_vote' => $myVote,
            // XE3 는 같은 추천을 한 번 더 누르면 취소된다
            'can_cancel_vote' => true,
            'is_mine' => $mine,
            'can_scrap' => $loggedIn,
            'can_declare' => $loggedIn && !$mine && app('xe.plugin')->getPlugin('claim') !== null,
            // 이미 내 스크랩(=즐겨찾기)에 있는지 (0.3.0~)
            'scrapped' => $loggedIn && $handler->hasFavorite($doc->id, $user->getId()),
        ];
    }

    private static function readableDocument()
    {
        list($item, $config) = self::board();
        $doc = self::document($item);
        if (!Boards::grant($item->id)['view'] && $doc->user_id !== Auth::id()) {
            throw self::denied();
        }
        return [$item, $config, $doc];
    }

    /** 추천(point 1)·비추천(-1). cancel 이면 취소. 웹 vote() 와 같은 핸들러 */
    public static function vote()
    {
        list($item, $config, $doc) = self::readableDocument();
        $option = (int)Api::param('point', 1) < 0 ? 'dissent' : 'assent';
        if ($config->get($option) !== true) {
            throw new ApiError(403, 'not_permitted', $option === 'assent' ? Text::t('이 게시판은 추천을 쓰지 않습니다.') : Text::t('이 게시판은 비추천을 쓰지 않습니다.'));
        }
        if ($doc->user_id === Auth::id()) {
            throw new ApiError(403, 'not_permitted', '자기 글은 추천할 수 없습니다.');
        }
        $handler = app('xe.board.handler');
        $has = $handler->hasVote($doc, Auth::user(), $option);
        $cancel = (bool)Api::param('cancel');
        if ($has === $cancel) {
            $handler->vote($doc, Auth::user(), $option); // 있으면 취소, 없으면 추천 (웹과 같은 동작)
            if (!$has) {
                $doc->refresh();
                Points::voted($doc, $option); // 추천받은 글쓴이 포인트 (웹과 같게)
            }
        } elseif (!$cancel) {
            throw new ApiError(400, 'already_voted', $option === 'assent' ? Text::t('이미 추천했습니다.') : Text::t('이미 비추천했습니다.'));
        }
        $doc->refresh();
        return self::actions($doc, $item, $config);
    }

    /** 추천한 사람: 웹(BoardModuleController::votedUsers)과 같은 기록(추천 카운터 로그) */
    public static function voters()
    {
        list(, $config, $doc) = self::readableDocument();
        $option = (int)Api::param('point', 1) < 0 ? 'dissent' : 'assent';
        if ($config->get($option) !== true) {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        $counter = app('xe.board.handler')->getVoteCounter();
        $logs = $counter->newModel()->where('counter_name', $counter->getName())->where('target_id', $doc->id)
            ->where('counter_option', $option)->orderBy('created_at', 'desc')->take(500)->get();
        $voters = [];
        foreach ($logs as $log) {
            $user = $log->user_id ? \Xpressengine\User\Models\User::find($log->user_id) : null;
            if ($user) {
                $voters[] = ['nick_name' => (string)$user->getDisplayName(), 'profile_image' => Api::profileImage($user)];
            }
        }
        return ['voters' => $voters];
    }

    /** 스크랩 = XE3 게시판 즐겨찾기 */
    public static function scrap()
    {
        list(, , $doc) = self::readableDocument();
        $handler = app('xe.board.handler');
        if ($handler->hasFavorite($doc->id, Auth::id()) === false) {
            $handler->addFavorite($doc->id, Auth::id());
        }
        return ['scrapped' => true];
    }

    /** 신고 = claim 플러그인 (웹 글 메뉴의 신고와 같은 기록) */
    public static function report()
    {
        list(, , $doc) = self::readableDocument();
        $claim = app('xe.claim.handler');
        $claim->set('module/board@board');
        try {
            $claim->add($doc->id, Auth::user(), (string)app('xe.board.url')->getShow($doc));
        } catch (\Exception $e) {
            throw new ApiError(400, 'already_declared', '이미 신고한 글입니다.');
        }
        return ['declared' => true];
    }
}
