<?php
namespace Xpressengine\Plugins\Appapi;

/**
 * 플러그인 문구 언어 (한국어·영어). 한국어 원문을 열쇠로 Text::t('…') 에 넣고, 값 자리는 {0}, {1} …
 * 영어 문구는 lang/text.en.php (한국어 원문 → 영어). XE1 모듈의 appapiText 와 같은 방식이다.
 * 앱에 보내는 문구(오류 등)는 앱이 보낸 언어(X-App-Lang: ko|en), 없으면(예전 앱) 사이트 언어.
 * 엔진이 만든 문구와 사이트 내용(글)은 바꾸지 않는다.
 */
class Text
{
    private static $code = null;
    private static $english = null;

    /** 이번 요청의 문구 언어: ko 또는 en */
    public static function code()
    {
        if (self::$code === null) {
            $requested = Api::$request ? strtolower(substr((string)Api::$request->header('X-App-Lang', ''), 0, 2)) : '';
            if ($requested === 'ko' || $requested === 'en') {
                self::$code = $requested;
            } else {
                $site = '';
                try {
                    $site = (string)app('xe.translator')->getLocale();
                } catch (\Throwable $e) {
                }
                self::$code = ($site === '' || $site === 'ko') ? 'ko' : 'en';
            }
        }
        return self::$code;
    }

    public static function t($ko, ...$args)
    {
        $text = $ko;
        if (self::code() === 'en') {
            if (self::$english === null) {
                $file = dirname(__DIR__) . '/lang/text.en.php';
                self::$english = is_file($file) ? (array)include $file : [];
            }
            if (isset(self::$english[$ko])) {
                $text = self::$english[$ko];
            }
        }
        foreach ($args as $i => $value) {
            $text = str_replace('{' . $i . '}', (string)$value, $text);
        }
        return $text;
    }
}
