<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Comment\Models\Comment;
use Xpressengine\User\Models\Guest as GuestUser;

/**
 * 비회원 글·댓글 확인 (0.3.5~, 기능 guest_manage): 웹의 비회원 인증과 같은 확인·같은 표시.
 *   글: BoardModuleController::guestCertify — IdentifyManager::verify(메일·비밀번호) 뒤 IdentifyManager::create
 *   댓글: 댓글 UserController::certify — 메일 비교 + Hash::check 뒤 Handler::certified
 * 웹은 이 표시를 세션에 10분 남기지만, 앱 주소는 세션을 쓰지 않아(쿠키 없음) 이번 요청 안에서만 쓰이고, 끝나면 지운다(forget).
 * 웹처럼 로그인하지 않은 사람만 확인한다: 회원은 비회원 글을 비밀번호로 고칠 수 없다(BoardService::hasItemPerm·CommentPolicy 가 비회원일 때만 허락).
 */
class Guest
{
    /** 웹 확인 화면이 받는 항목 (메일·비밀번호, Validator::guestCertifyRule·댓글 certify) */
    const CERTIFY_FIELDS = ['email_address', 'password'];

    private static $documents = [];

    /** 비밀번호를 연달아 틀릴 수 있는 횟수와 그 시간(초): 접속 주소 + 글·댓글마다 10분에 10번 */
    const MAX_FAILURES = 10;
    const FAILURE_WINDOW = 600;

    /** 보낸 비밀번호 (없으면 null). 로그인한 회원이 보낸 password 는 보지 않는다(회원은 토큰으로만 판단, 웹과 같다) */
    public static function password()
    {
        if (Auth::check()) {
            return null;
        }
        $password = Api::param('password');
        return is_string($password) && $password !== '' ? $password : null;
    }

    /** 로그인하지 않았고 비밀번호도 없으면 예전처럼 401 login_required */
    public static function requirePassword()
    {
        $password = self::password();
        if ($password === null) {
            throw new ApiError(401, 'login_required', Api::message('login_required'));
        }
        return $password;
    }

    private static function email()
    {
        $email = trim((string)Api::param('email_address', ''));
        if ($email === '') {
            throw new ApiError(400, 'guest_info_required', '메일과 비밀번호를 입력해 주세요.');
        }
        return $email;
    }

    private static function wrong()
    {
        return new ApiError(403, 'wrong_password', '메일 또는 비밀번호가 맞지 않습니다.');
    }

    /** 비회원 글을 이 요청에서 인증된 것으로 (웹 guestCertify 와 같은 확인). 회원 글이면 비밀번호로는 아무것도 안 된다 */
    public static function certifyDocument(Board $doc, $password)
    {
        if (Auth::check() || !$doc->isGuest() || (string)$doc->certify_key === '') {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        $identify = app('xe.board.identify');
        $email = self::email();
        $key = self::throttle('document', $doc->id);
        if ($identify->verify($doc, $email, $password) !== true) {
            throw self::failed($key);
        }
        $identify->create($doc);
        self::$documents[] = $doc;
    }

    /** 비회원 댓글을 이 요청에서 인증된 것으로 (웹 댓글 certify 와 같은 확인) */
    public static function certifyComment(Comment $comment, $password)
    {
        if (Auth::check() || !$comment->getAuthor() instanceof GuestUser || (string)$comment->certify_key === '') {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        $email = self::email();
        $key = self::throttle('comment', $comment->id);
        if ($email !== (string)$comment->email || Hash::check($password, (string)$comment->certify_key) === false) {
            throw self::failed($key);
        }
        app('xe.plugin.comment')->getHandler()->certified($comment);
    }

    /**
     * 비밀번호 맞히기를 막는다: 같은 접속 주소에서 같은 글·댓글에 10분 안에 10번 틀리면, 그 10분이 지날 때까지 429 too_many_attempts.
     * 사이트 캐시(XE3 cache 저장소, Laravel RateLimiter)에 센다. 캐시를 못 쓰면 막지 않는다(웹도 막지 않는다)
     */
    private static function throttle($type, $id)
    {
        $key = 'appapi.guest_pw.' . sha1($type . '|' . $id . '|' . (string)Api::$request->ip());
        try {
            $limiter = app(\Illuminate\Cache\RateLimiter::class);
            if ($limiter->tooManyAttempts($key, self::MAX_FAILURES)) {
                $minutes = max(1, (int)ceil($limiter->availableIn($key) / 60));
                throw new ApiError(429, 'too_many_attempts', Text::t('비밀번호를 여러 번 틀렸습니다. {0}분 뒤에 다시 해 주세요.', $minutes));
            }
        } catch (ApiError $e) {
            throw $e;
        } catch (\Throwable $e) {
            report($e);
        }
        return $key;
    }

    /** 틀린 비밀번호: 횟수를 세고 403 wrong_password */
    private static function failed($key)
    {
        try {
            app(\Illuminate\Cache\RateLimiter::class)->hit($key, self::FAILURE_WINDOW);
        } catch (\Throwable $e) {
            report($e);
        }
        return self::wrong();
    }

    /** 이번 요청에서 남긴 인증 표시를 지운다 (Api::handle 이 끝날 때) */
    public static function forget()
    {
        try {
            foreach (self::$documents as $doc) {
                app('xe.board.identify')->destroy($doc);
            }
            // 비회원이 댓글을 쓰면 엔진(Handler::create)도 표시를 남긴다
            app('session')->forget(\Xpressengine\Plugins\Comment\Handler::PLUGIN_PREFIX . '.certified');
        } catch (\Throwable $e) {
            report($e);
        }
        self::$documents = [];
    }
}
