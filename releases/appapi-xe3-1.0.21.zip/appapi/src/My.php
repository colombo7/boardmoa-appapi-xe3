<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Support\Facades\Auth;
use XeDB;
use XeMenu;
use Xpressengine\Document\Models\Document;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Board\Models\BoardFavorite;
use Xpressengine\Plugins\Comment\Models\Comment;
use Xpressengine\User\Models\User;

/**
 * 내 활동·내 정보 (로그인 필요).
 * XE3 에 있는 것만 메뉴로 보낸다: 내가 쓴 글·댓글, 스크랩(=게시판 즐겨찾기). 쪽지·친구·임시 저장은 XE3 에 없어 보내지 않는다.
 * 글은 지금도 목록 권한이 있는 게시판의 것만 (권한이 바뀐 게시판의 글이 새지 않게).
 */
class My
{
    const PER_PAGE = 20;

    public static function menu()
    {
        return ['items' => [
            ['key' => 'documents', 'title' => Text::t('내가 쓴 글')],
            ['key' => 'comments', 'title' => Text::t('내가 쓴 댓글')],
            ['key' => 'scraps', 'title' => Text::t('스크랩')],
        ]];
    }

    /** 목록을 볼 수 있는 게시판 [instance_id => 메뉴 항목] */
    private static function boards()
    {
        $out = [];
        foreach (XeMenu::items()->query()->where('type', Boards::BOARD)->get() as $item) {
            if (Boards::grant($item->id)['list']) {
                $out[$item->id] = $item;
            }
        }
        return $out;
    }

    private static function page()
    {
        return max(1, Api::intParam('page', 1));
    }

    private static function paging($paginate)
    {
        return ['page' => (int)$paginate->currentPage(), 'total_pages' => max(1, (int)$paginate->lastPage()), 'total_count' => (int)$paginate->total()];
    }

    public static function documents()
    {
        $boards = self::boards();
        $paginate = Board::whereIn('instance_id', array_keys($boards) ?: [''])
            ->where('user_id', Auth::id())
            ->where('status', '!=', Document::STATUS_TRASH)
            ->where('display', '!=', Document::DISPLAY_HIDDEN)
            ->orderBy('created_at', 'desc')
            ->paginate(self::PER_PAGE, ['*'], 'page', self::page());
        $documents = [];
        foreach ($paginate as $doc) {
            $item = $boards[$doc->instance_id];
            $summary = Boards::summary($doc, app('xe.board.config')->get($doc->instance_id), true);
            $summary['mid'] = (string)$item->url;
            $summary['board_title'] = Boards::title($item);
            $documents[] = $summary;
        }
        return ['documents' => $documents] + self::paging($paginate);
    }

    public static function comments()
    {
        $boards = self::boards();
        $handler = app('xe.plugin.comment')->getHandler();
        $map = [];
        foreach ($boards as $id => $item) {
            if ($commentInstance = $handler->getInstanceId($id)) {
                $map[$commentInstance] = $item;
            }
        }
        $paginate = Comment::whereIn('instance_id', array_keys($map) ?: [''])
            ->where('user_id', Auth::id())
            ->where('status', '!=', Document::STATUS_TRASH)
            ->where('display', '!=', Document::DISPLAY_HIDDEN)
            ->with('target')
            ->orderBy('created_at', 'desc')
            ->paginate(self::PER_PAGE, ['*'], 'page', self::page());
        $comments = [];
        foreach ($paginate as $c) {
            $doc = $c->target ? Board::find($c->target->target_id) : null;
            $item = $map[$c->instance_id];
            $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags(Boards::commentContent($c)), ENT_QUOTES, 'UTF-8')));
            $comments[] = [
                'comment_srl' => Store::num($c->id),
                'document_srl' => $doc ? Store::num($doc->id) : 0,
                'content' => mb_substr($text, 0, 200),
                'regdate' => $c->created_at ? $c->created_at->toIso8601String() : null,
                'is_secret' => (int)$c->display === Document::DISPLAY_SECRET,
                'document_title' => $doc ? (string)$doc->title : '',
                'mid' => (string)$item->url,
                'board_title' => Boards::title($item),
            ];
        }
        return ['comments' => $comments] + self::paging($paginate);
    }

    /** 스크랩 = 게시판 즐겨찾기. 지금 볼 수 없는 게시판의 글은 제목을 감춘다(exists:false) */
    public static function scraps()
    {
        $boards = self::boards();
        $paginate = BoardFavorite::where('user_id', Auth::id())->orderBy('favorite_id', 'desc')
            ->paginate(self::PER_PAGE, ['*'], 'page', self::page());
        $documents = [];
        foreach ($paginate as $fav) {
            $doc = Board::find($fav->target_id);
            $item = $doc ? ($boards[$doc->instance_id] ?? null) : null;
            $visible = $doc && $item && (int)$doc->status !== Document::STATUS_TRASH;
            $documents[] = [
                'document_srl' => Store::num($fav->target_id),
                'title' => $visible ? (string)$doc->title : '',
                'author' => $visible ? (string)$doc->writer : '',
                'scrapped_at' => null,
                'mid' => $item ? (string)$item->url : null,
                'board_title' => $item ? Boards::title($item) : null,
                'exists' => $visible,
            ];
        }
        return ['documents' => $documents, 'folders' => [], 'folder_srl' => 0] + self::paging($paginate);
    }

    public static function deleteScrap()
    {
        $uuid = Store::uuid(Api::intParam('document_srl'));
        if ($uuid) {
            app('xe.board.handler')->removeFavorite($uuid, Auth::id());
        }
        return ['deleted' => true];
    }

    // ---- 내 정보

    public static function form()
    {
        $user = Auth::user();
        return [
            'nick_name' => (string)$user->getDisplayName(),
            'email_address' => (string)$user->email,
            'profile_image' => Api::profileImage($user),
            'can_change_nickname' => true,
            // XE3 는 이메일을 바꾸면 인증 절차가 따로 있어 웹에서 한다
            'can_change_email' => false,
            // 웹 프로필(/@아이디)에서 회원이 사진을 올리고 자기소개를 고친다 (1.0.21~). 사진 지우기는 웹에도 관리자 화면에만 있다
            'profile_image_enabled' => true,
            'profile_image_deletable' => false,
            'fields' => [
                ['name' => 'introduction', 'title' => Text::t('자기소개'), 'type' => 'text', 'required' => false,
                    'value' => (string)$user->introduction, 'options' => [], 'parts' => [], 'editable' => true],
            ],
            'images' => [],
            'web_notice' => null,
            'web_url' => Boards::absolute(route('user.profile', [$user->getId()])),
        ];
    }

    /**
     * POST me.image multipart image → member (1.0.21~). 웹 프로필 수정(ProfileController::update)과 같은 처리:
     * xe.user.image 가 사이트 설정 크기로 맞춰 저장하고 예전 사진을 지운다. 지우기(delete)는 웹에도 회원 화면에 없어 403
     */
    public static function image()
    {
        if (Api::param('delete')) {
            throw new ApiError(403, 'not_permitted', '사진 지우기는 웹사이트 관리자에게 요청해 주세요.');
        }
        $file = Api::$request->file('image');
        if (!$file instanceof \Illuminate\Http\UploadedFile || !$file->isValid() || !@getimagesize((string)$file->getRealPath())) {
            throw new ApiError(400, 'upload_failed', '사진을 올리지 못했습니다.');
        }
        $user = Auth::user();
        XeDB::beginTransaction();
        try {
            $user->profile_image_id = app('xe.user.image')->updateUserProfileImage($user, $file);
            app('xe.user')->update($user, []);
            XeDB::commit();
        } catch (\Exception $e) {
            XeDB::rollback();
            throw new ApiError(400, 'upload_failed', $e->getMessage() ?: '사진을 올리지 못했습니다.');
        }
        Auth::setUser(User::find($user->getId()));
        return Api::profile();
    }

    /** 지금 비밀번호 확인. 회원마다 10분에 10번 틀리면 그동안 429 too_many_attempts (1.0.18~, Guest 와 같은 RateLimiter) */
    private static function checkPassword($password)
    {
        $user = Auth::user();
        $keys = Guest::memberThrottle($user->getId());
        if (!Auth::getProvider()->validateCredentials($user, ['password' => (string)$password])) {
            Guest::hit($keys);
            throw new ApiError(400, 'invalid_password', '지금 비밀번호가 맞지 않습니다.');
        }
    }

    /** 닉네임 바꾸기: 웹(UserController::updateDisplayName)과 같은 검사(중복·형식) 뒤 같은 핸들러로 */
    public static function update()
    {
        self::checkPassword(Api::param('current_password'));
        $user = Auth::user();
        $name = Api::param('nick_name');
        if ($name !== null) {
            $name = str_replace('  ', ' ', trim((string)$name));
            if ($name !== $user->getDisplayName()) {
                $handler = app('xe.user');
                try {
                    $handler->validateDisplayName($name, $user);
                } catch (\Exception $e) {
                    throw new ApiError(400, 'update_failed', $e->getMessage() ?: '쓸 수 없는 닉네임입니다.');
                }
                XeDB::beginTransaction();
                try {
                    $handler->update($user, ['display_name' => $name]);
                    XeDB::commit();
                } catch (\Exception $e) {
                    XeDB::rollback();
                    throw new ApiError(400, 'update_failed', $e->getMessage() ?: '바꾸지 못했습니다.');
                }
            }
        }
        // 자기소개 (1.0.21~): 웹 프로필 수정처럼 그대로 저장한다
        $fields = Api::$request->input('fields');
        if (is_string($fields)) {
            $fields = json_decode($fields, true);
        }
        // 빈 칸은 Laravel 이 null 로 넘긴다(ConvertEmptyStringsToNull): 자기소개를 지운 것
        if (is_array($fields) && array_key_exists('introduction', $fields) && (is_scalar($fields['introduction']) || $fields['introduction'] === null)) {
            // 웹 프로필은 자기소개를 HTML 그대로 그린다: 앱에서 온 글은 글자만 (한 줄 칸이라 꾸밈이 없다)
            $intro = trim(strip_tags((string)$fields['introduction']));
            $user = User::find($user->getId());
            if ($intro !== (string)$user->introduction) {
                XeDB::beginTransaction();
                try {
                    app('xe.user')->update($user, ['introduction' => $intro]);
                    XeDB::commit();
                } catch (\Exception $e) {
                    XeDB::rollback();
                    throw new ApiError(400, 'update_failed', $e->getMessage() ?: '바꾸지 못했습니다.');
                }
            }
        }
        Auth::setUser(User::find($user->getId()));
        return Api::profile();
    }

    /** 비밀번호 바꾸기: 웹과 같은 규칙(xe_password) — 바뀌면 다른 기기 토큰은 무효, 이 기기에는 새 토큰 */
    public static function password()
    {
        self::checkPassword(Api::param('current_password'));
        $new = (string)Api::param('new_password', '');
        $validator = validator(['password' => $new, 'password_confirmation' => $new], ['password' => 'required|confirmed|xe_password']);
        if ($validator->fails()) {
            throw new ApiError(400, 'invalid_password', $validator->errors()->first('password'));
        }
        $user = Auth::user();
        XeDB::beginTransaction();
        try {
            app('xe.user')->update($user, ['password' => $new]);
            XeDB::commit();
        } catch (\Exception $e) {
            XeDB::rollback();
            throw new ApiError(400, 'invalid_password', $e->getMessage() ?: '바꾸지 못했습니다.');
        }
        $user = User::find($user->getId());
        Store::revokeUser($user->getId());
        $tokens = Store::issue($user->getId(), $user->password, Api::$token->device_name ?? '', Api::$token->platform ?? '', Api::$request->ip());
        return ['tokens' => $tokens];
    }

    /**
     * 이름 메뉴: XE3 에는 쪽지·친구가 없어 '프로필 보기'(1.0.18~)와 '작성 글 보기'(그 회원의 글을 게시판에서 찾기).
     * 프로필 보기는 웹 이름 메뉴(회원 토글 메뉴 user)에 '프로필'이 켜져 있을 때만, 로그인했을 때만(앱의 member.info 는 로그인 필요 — 다른 모듈과 같다)
     */
    public static function memberMenu()
    {
        $memberSrl = Api::intParam('member_srl');
        $uuid = Store::uuid($memberSrl);
        $user = $uuid ? User::find($uuid) : null;
        $actions = [];
        if ($user && Auth::check() && self::profileMenu($user)) {
            $actions[] = ['type' => 'info', 'label' => Text::t('프로필 보기')];
        }
        if ($user && Api::param('mid')) {
            $actions[] = ['type' => 'documents', 'label' => Text::t('작성 글 보기'), 'mid' => (string)Api::param('mid'),
                'search' => ['search_target' => 'nick_name', 'search_keyword' => (string)$user->getDisplayName()]];
        }
        return ['member_srl' => $memberSrl, 'actions' => $actions];
    }

    /** 웹 이름 메뉴(XeToggleMenu 'user', 관리 화면 '토글 메뉴')에 프로필 항목이 켜져 있고 보일 수 있는가 */
    private static function profileMenu(User $user)
    {
        try {
            foreach (\XeToggleMenu::getItems('user', null, $user->getId()) as $menuItem) {
                if ($menuItem instanceof \App\ToggleMenus\User\ProfileItem && $menuItem->allows() !== false) {
                    return true;
                }
            }
        } catch (\Throwable $e) {
            report($e);
        }
        return false;
    }

    /**
     * 회원 정보 (1.0.18~): 웹 프로필 화면(/@회원, ProfileController::index·기본 프로필 스킨)에 보이는 것만 — 사진·이름·소개, 회원 그룹은 사이트 관리자(매니저 이상)에게만.
     * XE3 프로필 화면은 가입일을 보이지 않아 regdate 는 null. 로그인한 회원만(다른 모듈과 같다, 웹은 누구나 연다), 이름 메뉴에 프로필이 꺼져 있으면 본인·관리자 말고는 403
     */
    public static function memberInfo()
    {
        $memberSrl = Api::intParam('member_srl');
        if (!$memberSrl) {
            throw new ApiError(400, 'missing_member_srl', 'member_srl is required');
        }
        $uuid = Store::uuid($memberSrl);
        $user = $uuid ? User::find($uuid) : null;
        if (!$user) {
            throw new ApiError(404, 'member_not_found', '없는 회원입니다.');
        }
        $me = Auth::user();
        $manager = \Xpressengine\User\Rating::compare($me->getRating(), \Xpressengine\User\Rating::MANAGER) >= 0;
        if ($me->getId() !== $user->getId() && !$manager && !self::profileMenu($user)) {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        $fields = [];
        if ($manager) {
            $groups = [];
            foreach ($user->groups as $group) {
                $groups[] = (string)$group->name;
            }
            if ($groups) {
                $fields[] = ['name' => 'group_list', 'title' => (string)xe_trans('xe::group'), 'value' => implode(', ', $groups)];
            }
        }
        $intro = trim(html_entity_decode(strip_tags(preg_replace('#<br\s*/?>#i', "\n", (string)$user->introduction)), ENT_QUOTES, 'UTF-8'));
        if ($intro !== '') {
            $fields[] = ['name' => 'introduction', 'title' => (string)xe_trans('xe::introduction'), 'value' => $intro];
        }
        return [
            'member_srl' => $memberSrl,
            'nick_name' => (string)$user->getDisplayName(),
            'profile_image' => Api::profileImage($user),
            'regdate' => null,
            'fields' => $fields,
        ];
    }

    /** 회원가입은 XE3 웹에서 (약관·가입 항목·메일 인증 절차가 사이트마다 달라서) */
    /**
     * 가입: 앱에서 받지 않고 웹 가입 화면으로(web_only). enabled 는 사이트가 가입을 받는지(관리 화면 '회원 가입 허용', user.register.joinable) —
     * 받으면 앱이 '가입' 단추로 web_url 을 연다. needs_confirm: 가입 뒤 바로 활성이 아니면(메일 인증·관리자 승인) true
     */
    public static function signupForm()
    {
        $joinable = false;
        $confirm = false;
        try {
            $config = app('xe.config')->get('user.register');
            $joinable = $config ? (bool)$config->get('joinable', false) : false;
            $confirm = $config ? ((string)$config->get('register_process', 'activated') !== 'activated') : false;
        } catch (\Throwable $e) {
            report($e);
        }
        return ['enabled' => $joinable, 'web_only' => true, 'web_url' => rtrim(url('/'), '/') . '/auth/register', 'basic' => [], 'agreements' => [],
            'password_hint' => '', 'needs_confirm' => $confirm, 'fields' => []];
    }
}
